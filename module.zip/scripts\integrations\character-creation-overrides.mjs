import { CONTENT_MODULE_ID, MODULE_ID } from "../core/constants.mjs";
import {
  deduplicatePreferredContent,
  normalizedDocumentName,
  packageIdFor
} from "../core/compendium-deduplication.mjs";

const ITEM_PACK = `${CONTENT_MODULE_ID}.items`;
const CLASS_PACK = `${CONTENT_MODULE_ID}.classes`;
const SUBCLASS_PACK = `${CONTENT_MODULE_ID}.subclasses`;

let installed = false;
let synchronization = null;
const uuidOverrides = new Map();

function identifierOf(document) {
  return String(document?.system?.identifier?.value ?? document?.identifier ?? "").trim();
}

function normalizedIdentifier(value) {
  return String(value ?? "").toLocaleLowerCase("en").replaceAll(/[^a-z0-9]/g, "");
}

function moveToEnd(values, value) {
  const remaining = values.filter(entry => entry !== value);
  remaining.push(value);
  return remaining;
}

function groupBy(values, callback) {
  const groups = new Map();
  for (const value of values) {
    const key = callback(value);
    const group = groups.get(key) ?? [];
    group.push(value);
    groups.set(key, group);
  }
  return groups;
}

async function prioritizeClasses() {
  const pack = game.packs.get(CLASS_PACK);
  if (!pack) return { prioritized: 0, conflicts: 0 };

  let prioritized = 0;
  let conflicts = 0;
  const classes = (await pack.getDocuments()).filter(document => document.type === "class");
  const byIdentifier = groupBy(classes, identifierOf);

  for (const [identifier, documents] of byIdentifier) {
    if (!identifier) continue;
    if (documents.length !== 1) {
      conflicts += 1;
      console.warn(
        `${MODULE_ID} | Cannot prioritize class "${identifier}": ${documents.length} Feuerschwinge entries found.`,
        documents.map(document => document.uuid)
      );
      continue;
    }

    const document = documents[0];
    const registration = CONFIG.BlackFlag.registration.get("class", identifier);
    if (!registration) {
      console.warn(`${MODULE_ID} | Cannot prioritize unregistered class "${identifier}" (${document.uuid}).`);
      continue;
    }

    registration.sources = moveToEnd(registration.sources, document.uuid);
    registration.name = document.name;
    registration.img = document.img;
    prioritized += 1;
  }

  return { prioritized, conflicts };
}

function prioritizeSubclasses() {
  let prioritized = 0;
  let conflicts = 0;
  for (const [identifier, registration] of Object.entries(CONFIG.BlackFlag.registration.list("subclass") ?? {})) {
    const matches = registration.sources.filter(uuid => uuid.startsWith(`Compendium.${CONTENT_MODULE_ID}.`));
    if (!matches.length) continue;
    if (matches.length !== 1) {
      conflicts += 1;
      console.warn(
        `${MODULE_ID} | Cannot prioritize subclass "${identifier}": ${matches.length} Feuerschwinge entries found.`,
        matches
      );
      continue;
    }
    registration.sources = moveToEnd(registration.sources, matches[0]);
    prioritized += 1;
  }
  return { prioritized, conflicts };
}

function configuredWeapons() {
  const weapons = CONFIG.BlackFlag.weapons;
  if (!weapons) return [];

  const entries = [];
  for (const category of ["simple", "martial"]) {
    for (const [base, configuration] of Object.entries(weapons[category]?.children ?? {})) {
      if (configuration.link) entries.push({ base, category, configuration });
    }
  }
  return entries;
}

async function prioritizeWeapons() {
  uuidOverrides.clear();
  const pack = game.packs.get(ITEM_PACK);
  if (!pack) return { prioritized: 0, missing: 0, conflicts: 0 };

  const documents = (await pack.getDocuments()).filter(document => document.type === "weapon");
  const byIdentifier = groupBy(documents, identifierOf);
  const byBase = groupBy(documents, document => {
    const category = String(document.system?.type?.category ?? "").trim();
    const base = String(document.system?.type?.base ?? "").trim();
    return category && base ? `${category}.${base}` : "";
  });
  const aliases = new Map();
  let prioritized = 0;
  let missing = 0;
  let conflicts = 0;

  for (const { base, category, configuration } of configuredWeapons()) {
    const officialUuid = configuration.__tovfOriginalLink ?? configuration.link;
    Object.defineProperty(configuration, "__tovfOriginalLink", {
      value: officialUuid,
      configurable: true,
      writable: true
    });

    let official;
    try {
      official = await fromUuid(officialUuid);
    } catch (error) {
      console.warn(`${MODULE_ID} | Could not resolve the Black Flag ${base} weapon (${officialUuid}).`, error);
    }
    const identifier = identifierOf(official);
    const baseMatches = byBase.get(`${category}.${base}`) ?? [];
    let matches = baseMatches;
    if (matches.length > 1) {
      const standardMatches = matches.filter(document => (
        normalizedIdentifier(identifierOf(document)) === normalizedIdentifier(base)
      ));
      if (standardMatches.length) matches = standardMatches;
    }
    if (!matches.length && identifier) matches = byIdentifier.get(identifier) ?? [];

    if (matches.length === 0) {
      missing += 1;
      configuration.link = officialUuid;
      console.warn(
        `${MODULE_ID} | No Feuerschwinge override found for ${category} weapon "${base}"`,
        { identifier, officialUuid }
      );
      continue;
    }
    if (matches.length !== 1) {
      conflicts += 1;
      configuration.link = officialUuid;
      console.warn(
        `${MODULE_ID} | Cannot override ${category} weapon "${base}": ${matches.length} entries share identifier "${identifier}".`,
        matches.map(document => document.uuid)
      );
      continue;
    }

    const replacement = matches[0];
    configuration.link = replacement.uuid;
    const alias = aliases.get(officialUuid) ?? { official, replacements: new Map() };
    alias.official ??= official;
    alias.replacements.set(replacement.uuid, replacement);
    aliases.set(officialUuid, alias);
    prioritized += 1;
  }

  for (const [officialUuid, { official, replacements }] of aliases) {
    if (replacements.size === 1) {
      uuidOverrides.set(officialUuid, replacements.keys().next().value);
      continue;
    }

    // Some Black Flag configuration entries incorrectly share a UUID. A bare
    // UUID still means the document it actually resolves to, while category
    // choices have already been routed independently using category and base.
    const officialIdentifier = identifierOf(official);
    const directMatches = [...replacements.values()].filter(document => (
      identifierOf(document) === officialIdentifier
    ));
    if (directMatches.length === 1) {
      uuidOverrides.set(officialUuid, directMatches[0].uuid);
    } else {
      console.warn(
        `${MODULE_ID} | Direct equipment link ${officialUuid} is ambiguous and will not be overridden.`,
        [...replacements.keys()]
      );
    }
  }

  return { prioritized, missing, conflicts };
}

async function synchronizeCharacterCreationOverrides() {
  if (synchronization) return synchronization;
  synchronization = Promise.all([prioritizeClasses(), prioritizeWeapons(), prioritizeSubclasses()])
    .then(([classes, weapons, subclasses]) => {
      console.info(`${MODULE_ID} | Character Creation overrides synchronized.`, { classes, weapons, subclasses });
      return { classes, weapons, subclasses };
    })
    .catch(error => {
      console.error(`${MODULE_ID} | Character Creation override synchronization failed.`, error);
    })
    .finally(() => {
      synchronization = null;
    });
  return synchronization;
}

function installSubclassChoiceDeduplication() {
  const prototype = BlackFlag?.applications?.actor?.ConceptSelectionDialog?.prototype;
  const original = prototype?._prepareContext;
  if (typeof original !== "function" || original.__tovfSubclassDeduplication) return;

  async function prepareContext(options) {
    const context = await original.call(this, options);
    if (this.type !== "subclass" || !Array.isArray(context.choices)) return context;
    context.choices = deduplicatePreferredContent(context.choices, {
      identity: choice => `subclass|${normalizedDocumentName(choice.document?.name)}`,
      source: choice => packageIdFor(game.packs.get(choice.document?.pack))
    });
    return context;
  }
  Object.defineProperty(prepareContext, "__tovfSubclassDeduplication", { value: true });
  prototype._prepareContext = prepareContext;
}

function installEquipmentUuidResolver() {
  const EquipmentEntryData = BlackFlag?.data?.advancement?.EquipmentEntryData;
  const prototype = EquipmentEntryData?.prototype;
  const original = prototype?.findSelection;
  if (typeof original !== "function" || original.__tovfCharacterCreationResolver) return;

  function findSelection(selection) {
    const uuid = original.call(this, selection);
    return uuidOverrides.get(uuid) ?? uuid;
  }
  Object.defineProperty(findSelection, "__tovfCharacterCreationResolver", { value: true });
  prototype.findSelection = findSelection;
}

function installEquipmentDialogGuard() {
  const EquipmentDialog = BlackFlag?.applications?.advancement?.EquipmentDialog;
  const prototype = EquipmentDialog?.prototype;
  const original = prototype?._prepareEquipmentEntry;
  if (typeof original !== "function" || original.__tovfMissingEquipmentGuard) return;

  async function prepareEquipmentEntry(entry) {
    if (entry?.type === "linked" && entry.requiresProficiency) {
      const item = await fromUuid(entry.key).catch(() => null);
      if (!item) {
        console.warn(
          `${MODULE_ID} | Disabled unresolved equipment advancement entry instead of aborting the equipment dialog.`,
          { uuid: entry.key, entry }
        );
        return {
          count: entry.type in entry.constructor.OPTION_TYPES ? entry.count ?? 1 : null,
          disabled: true,
          entry,
          entries: await Promise.all(entry.children.map(child => this._prepareEquipmentEntry(child))),
          label: entry.type === "currency"
            ? CONFIG.BlackFlag.currencies.localizedAbbreviation[entry.key]?.toUpperCase()
            : entry.label,
          options: entry.optionsWithProficiency(this.actor)
        };
      }
    }
    return original.call(this, entry);
  }
  Object.defineProperty(prepareEquipmentEntry, "__tovfMissingEquipmentGuard", { value: true });
  prototype._prepareEquipmentEntry = prepareEquipmentEntry;
}

/**
 * Prefer Feuerschwinge classes and standard weapons in Black Flag's existing
 * Character Creation without replacing its selection flow.
 */
export function installCharacterCreationOverrides() {
  if (installed) return { status: "already-installed" };
  const missing = [];
  if (!CONFIG.BlackFlag?.registration) missing.push("CONFIG.BlackFlag.registration");
  if (typeof BlackFlag?.data?.advancement?.EquipmentEntryData?.prototype?.findSelection !== "function") {
    missing.push("EquipmentEntryData.findSelection");
  }
  if (typeof BlackFlag?.applications?.advancement?.EquipmentDialog?.prototype?._prepareEquipmentEntry !== "function") {
    missing.push("EquipmentDialog._prepareEquipmentEntry");
  }
  if (typeof BlackFlag?.applications?.actor?.ConceptSelectionDialog?.prototype?._prepareContext !== "function") {
    missing.push("ConceptSelectionDialog._prepareContext");
  }
  if (missing.length) {
    return { status: "incompatible", reason: `Missing Black Flag APIs: ${missing.join(", ")}.` };
  }
  installed = true;

  installEquipmentUuidResolver();
  installEquipmentDialogGuard();
  installSubclassChoiceDeduplication();
  if (CONFIG.BlackFlag.registration.ready) void synchronizeCharacterCreationOverrides();
  else Hooks.once("blackFlag.registrationComplete", synchronizeCharacterCreationOverrides);

  Hooks.on("createItem", item => {
    if ([ITEM_PACK, CLASS_PACK, SUBCLASS_PACK].includes(item.pack)) void synchronizeCharacterCreationOverrides();
  });
  Hooks.on("updateItem", item => {
    if ([ITEM_PACK, CLASS_PACK, SUBCLASS_PACK].includes(item.pack)) void synchronizeCharacterCreationOverrides();
  });
  Hooks.on("deleteItem", item => {
    if ([ITEM_PACK, CLASS_PACK, SUBCLASS_PACK].includes(item.pack)) void synchronizeCharacterCreationOverrides();
  });
  return { status: "completed" };
}

export const characterCreationOverridesApi = {
  resolveUuid(uuid) {
    return uuidOverrides.get(uuid) ?? uuid;
  },
  synchronize: synchronizeCharacterCreationOverrides
};
