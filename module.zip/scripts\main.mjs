import { MODULE_ID } from "./core/constants.mjs";
import { installConcentration } from "./concentration.mjs";
import { registerMigrationSettings, runMigrations } from "./core/migrations.mjs";
import {
  installLegacyNamespaceGuard,
  migrateToolNamespace,
  registerNamespaceMigration
} from "./core/namespace-migration.mjs";
import { exposeTransferApi } from "./transfer/compendium-transfer.mjs?v=3.6.2-transfer-integrity-9";
import { registerSessionTransfer, sessionTransferApi } from "./transfer/session-transfer.mjs";
import { installBlackFlagCompatibility } from "./integrations/black-flag-compatibility.mjs?v=3.6.2-compat-log-1";
import {
  characterCreationOverridesApi,
  installCharacterCreationOverrides
} from "./integrations/character-creation-overrides.mjs";
import {
  installWeaponOptionActivities,
  weaponOptionActivitiesApi
} from "./integrations/weapon-option-activities.mjs?v=3.2.4-tooltip-links-2";
import { installArgonBlackFlagCompatibility } from "./integrations/argon-black-flag-compatibility.mjs?v=3.4.2-argon-settings-popup-1";
import { activatePlayerUnpause, registerPlayerUnpause } from "./player-unpause.mjs";
import { registerCompendiumLibrary } from "./compendium-library.mjs?v=3.5.0-feuerschwinge-spell-priority-1";
import { activateChallengeManager, registerChallengeManager } from "./challenge-manager.mjs";
import { registerLinkTools } from "./link-tools-config.mjs";
import {
  activateFeaturePoolIntegration,
  registerFeaturePoolIntegration
} from "./feature-pool-integration.mjs";
import { registerTokenSizeSync } from "./token-size-sync.mjs";
import { creatureBuilderApi, registerCreatureBuilder } from "./creature-builder.mjs";
import { registerSettingsCategories } from "./settings-categories.mjs";
import { registerHelp } from "./help-config.mjs";
import { activityChainingApi, installActivityChaining } from "./activity-chaining.mjs?v=3.3.1-follow-up-filter-2";
import { installToolAbilitySelection } from "./integrations/tool-ability.mjs";
import { installTheurgeSpellcasting } from "./integrations/theurge-spellcasting.mjs?v=3.3.0-manual-theurge-mode-1";
import { installCompendiumUsability } from "./compendium-usability.mjs";
import { installChatImagePopouts } from "./chat-image-popout.mjs";
import { registerChatMessageDeletion } from "./chat-message-deletion.mjs";
import { installChatTimestamps } from "./chat-timestamps.mjs";
import { createMagicalDrinkWorldItems, effectGroupsApi, installEffectGroups } from "./effect-groups.mjs?v=3.2.5-effect-groups-7";
import { activateTokenPresetSocket, registerTokenPresets } from "./token-presets.mjs";
import { activateTokenLightAuraSocket, toggleTokenLightAura } from "./token-light-aura.mjs";
import { activateSimpleTileTriggers, registerSimpleTileTriggers } from "./simple-tile-triggers.mjs?v=3.2.2";
import { activateSummonCompatibility } from "./summon-compat.mjs?v=3.6.2-character-summon-folder-1";
import { activateCommerce, registerCommerce } from "./commerce/main.mjs?v=3.6.2-actorless-preview-1";
import "./downtime/main.mjs?v=3.5.0-actor-spell-migration-10";
import "./contested-activity.mjs";
import "./void-taint/main.mjs?v=3.3.0-void-taint-1";
import { registerTalentBackgrounds } from "./talent-backgrounds.mjs?v=3.3.1-talent-backgrounds-6";
import { installCustomBackground } from "./integrations/custom-background.mjs?v=3.3.1-custom-background-16";
import { installActiveEffectChangesUi } from "./active-effect-changes-ui.mjs";
import { installSpellScrollTools } from "./spell-scrolls.mjs?v=3.5.0-spell-scrolls-3";
import { installSpellNameMarkers } from "./spell-name-markers.mjs?v=3.5.0-spell-markers-1";

// Keep tile triggers independent from the shared initialization chain so an
// unrelated tool cannot prevent their hooks and diagnostics from registering.
registerSimpleTileTriggers();
Hooks.once("ready", activateSimpleTileTriggers);
registerCommerce();
Hooks.once("ready", activateCommerce);
installChatTimestamps();

const MODULE_MENU_ORDER = new Map([
  ["help", 0],
  ["creatureBuilder", 10],
  ["compendiumTransfer", 20],
  ["characterLinkTools", 40],
  ["weaponCustomization", 50],
  ["argonCombatHud", 55],
  ["itemDefaults", 60],
  ["playerActorFolders", 70],
  ["sessionRewards", 80]
]);

const MODULE_SETTING_ORDER = new Map([
  ["worldRole", 0],
  ["automaticTokenSizing", 10],
  ["unpauseWithoutGM", 20],
  ["sessionHistoryEnabled", 30]
]);

function localConfigurationKey(key, prefix) {
  return key.slice(prefix.length);
}

function localizedConfigurationName(registry, key) {
  return game.i18n.localize(registry.get(key)?.name ?? key);
}

function reorderModuleEntries(registry, order, { configuredOnly = false } = {}) {
  const prefix = `${MODULE_ID}.`;
  const own = [...registry].filter(([key, value]) => (
    key.startsWith(prefix) && (!configuredOnly || value.config === true)
  ));
  if (!own.length) return;
  own.sort(([left], [right]) => {
    const leftRank = order.get(localConfigurationKey(left, prefix)) ?? 1000;
    const rightRank = order.get(localConfigurationKey(right, prefix)) ?? 1000;
    if (leftRank !== rightRank) return leftRank - rightRank;
    return localizedConfigurationName(registry, left)
      .localeCompare(localizedConfigurationName(registry, right), game.i18n.lang);
  });
  const ownKeys = new Set(own.map(([key]) => key));
  const ordered = [];
  let inserted = false;
  for (const entry of registry) {
    if (!ownKeys.has(entry[0])) {
      ordered.push(entry);
      continue;
    }
    if (!inserted) ordered.push(...own);
    inserted = true;
  }
  registry.clear();
  for (const [key, value] of ordered) registry.set(key, value);
}

function orderModuleMenus() {
  reorderModuleEntries(game.settings.menus, MODULE_MENU_ORDER);
  reorderModuleEntries(game.settings.settings, MODULE_SETTING_ORDER, { configuredOnly: true });
}

Hooks.once("init", () => {
  if (game.system.id !== "black-flag") return;
  installBlackFlagCompatibility();
  installCharacterCreationOverrides();
  installWeaponOptionActivities();
  installActivityChaining();
  installToolAbilitySelection();
  installTheurgeSpellcasting();
  installCompendiumUsability();
  installChatImagePopouts();
  registerChatMessageDeletion();
  registerTalentBackgrounds();
  installCustomBackground();
  installActiveEffectChangesUi();
  installSpellScrollTools();
  installSpellNameMarkers();
  installConcentration();
  installEffectGroups();
  registerTokenPresets();
  installArgonBlackFlagCompatibility();
  registerPlayerUnpause();
  registerCompendiumLibrary();
  registerChallengeManager();
  registerFeaturePoolIntegration();
  registerTokenSizeSync();
  registerCreatureBuilder();
  registerHelp();
  registerSettingsCategories();
  registerNamespaceMigration();
  registerMigrationSettings();
  registerSessionTransfer();
  queueMicrotask(registerLinkTools);
});

Hooks.once("ready", async () => {
  activateSummonCompatibility();
  if (game.system.id !== "black-flag") return;
  let namespaceMigrationSucceeded = true;
  try {
    await migrateToolNamespace();
  } catch (error) {
    namespaceMigrationSucceeded = false;
    console.error(`${MODULE_ID} | Namespace migration failed`, error);
    ui.notifications.error(`Feuerschwinge-Tools: Die Übernahme alter Einstellungen und Flags ist fehlgeschlagen: ${error.message}`, { permanent: true });
  }
  installLegacyNamespaceGuard();
  orderModuleMenus();
  activatePlayerUnpause();
  activateChallengeManager();
  activateTokenPresetSocket();
  activateTokenLightAuraSocket();
  await activateFeaturePoolIntegration();
  if (game.user.isGM) {
    try {
      await createMagicalDrinkWorldItems();
    } catch (error) {
      console.error(`${MODULE_ID} | Creating magical drink World Items failed.`, error);
      ui.notifications.error(`Magische Getränke konnten nicht angelegt werden: ${error.message}`);
    }
  }
  exposeTransferApi();
  Object.assign(game.modules.get(MODULE_ID).api, sessionTransferApi());
  Object.assign(game.modules.get(MODULE_ID).api, creatureBuilderApi());
  Object.assign(game.modules.get(MODULE_ID).api, {
    toggleTokenLightAura,
    activityChaining: activityChainingApi,
    effectGroups: effectGroupsApi,
    characterCreationOverrides: characterCreationOverridesApi,
    weaponOptionActivities: weaponOptionActivitiesApi
  });
  if (namespaceMigrationSucceeded) {
    try {
      await runMigrations();
    } catch (error) {
      console.error(`${MODULE_ID} | Migration failed`, error);
      ui.notifications.error(game.i18n.format("TOVF.Migration.Error", { message: error.message }));
    }
  }
});
