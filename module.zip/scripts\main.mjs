import { MODULE_ID } from "./core/constants.mjs";
import { activateDowntime, registerDowntime } from "./downtime/main.mjs?v=3.8.5-raffle-withdraw-9";
import { activateVoidTaint, registerVoidTaint } from "./void-taint/main.mjs?v=3.3.0-void-taint-1";
import { installBlackFlagCompatibility } from "./integrations/black-flag-compatibility.mjs?v=3.7.8-forward-consumption-1";
import {
  loadStartupModule,
  notifyStartupFailures,
  runStartupStep,
  runStartupStepAsync,
  runStartupSteps,
  startupApi
} from "./core/startup.mjs?v=3.8.0-isolated-feature-loads-1";

const BLACK_FLAG_FEATURE_MODULES = Object.freeze({
  events: "./core/events.mjs?v=3.7.8-module-events-1",
  scheduler: "./core/scheduler.mjs?v=3.11.5-task-authority-1",
  concentration: "./concentration.mjs?v=3.7.8-safe-documents-1",
  migrations: "./core/migrations.mjs",
  namespaceMigration: "./core/namespace-migration.mjs?v=3.8.0-storage-api-2",
  compendiumTransfer: "./transfer/compendium-transfer.mjs?v=3.6.2-transfer-integrity-9",
  sessionTransfer: "./transfer/session-transfer.mjs?v=3.7.8-safe-documents-1",
  characterCreation: "./integrations/character-creation-overrides.mjs",
  weaponOptions: "./integrations/weapon-option-activities.mjs?v=3.2.4-tooltip-links-2",
  playerUnpause: "./player-unpause.mjs",
  compendiumLibrary: "./compendium-library.mjs?v=3.8.5-item-library-filters-2",
  dnd5eItemImporter: "./dnd5e-item-importer.mjs?v=3.8.0-import-spell-school-1",
  challengeManager: "./challenge-manager.mjs?v=3.12.2-initiative-carousel-dialog-1",
  linkTools: "./link-tools-config.mjs",
  featurePool: "./feature-pool-integration.mjs",
  tokenSizeSync: "./token-size-sync.mjs",
  tokenDistanceDisplay: "./token-distance-display.mjs?v=3.11.5-token-distance-display-1",
  tokenPatrol: "./token-patrol.mjs?v=3.11.5-token-patrol-10",
  moduleConflicts: "./module-conflicts.mjs?v=3.11.5-module-conflicts-1",
  creatureBuilder: "./creature-builder.mjs",
  actorDirectoryActivity: "./actor-directory-activity.mjs?v=3.8.0-inactive-markers-3",
  settingsCategories: "./settings-categories.mjs",
  help: "./help-config.mjs",
  activityChaining: "./activity-chaining.mjs?v=3.3.1-follow-up-filter-2",
  compatibility: "./integrations/compatibility-layer.mjs?v=3.11.5-luck-reroll-dsn-1",
  compendiumUsability: "./compendium-usability.mjs",
  chatImagePopouts: "./chat-image-popout.mjs",
  chatMessageDeletion: "./chat-message-deletion.mjs",
  chatTimestamps: "./chat-timestamps.mjs",
  effectGroups: "./effect-groups.mjs?v=3.7.8-safe-documents-1",
  tokenHudMenu: "./token-hud-menu.mjs?v=3.10.1-native-token-hud-palette-6",
  tokenPresets: "./token-presets.mjs?v=3.10.1-native-token-hud-palette-3",
  tokenLightAura: "./token-light-aura.mjs",
  simpleTileTriggers: "./simple-tile-triggers.mjs?v=3.8.5-scene-hud-3",
  sceneItemLoot: "./scene-item-loot.mjs?v=3.9.3-scene-item-loot-18",
  sceneActionHud: "./scene-action-hud.mjs?v=3.8.5-scene-hud-9",
  serverUpdateWarning: "./server-update-warning.mjs?v=3.11.3-all-connected-1",
  commerce: "./commerce/main.mjs?v=3.8.5-merchant-interactor-avatar-1",
  contestedActivity: "./contested-activity.mjs?v=3.10.1-npc-skill-ability-1",
  talentBackgrounds: "./talent-backgrounds.mjs?v=3.3.1-talent-backgrounds-6",
  characterOptionIndex: "./character-option-index.mjs?v=3.9.3-character-option-index-1",
  spellScrolls: "./spell-scrolls.mjs?v=3.7.8-clearance-label-1",
  spellNameMarkers: "./spell-name-markers.mjs?v=3.5.0-spell-markers-1",
  selectedTokenEffectsHud: "./selected-token-effects-hud.mjs?v=3.8.0-selected-token-effects-3",
  macroActivity: "./macro-activity.mjs",
  weaponCustomization: "./weapon-customization.mjs",
  weaponEnchantment: "./weapon-enchantment.mjs",
  mounting: "./mounting.mjs?v=3.10.1-owner-authority-10"
});
const DND5E_FEATURE_MODULES = Object.freeze({
  dnd5eBundleExporter: "./import/dnd5e-bundle-exporter.mjs?v=3.8.0-content-bundle-2"
});

function featureModulesForSystem(systemId) {
  if (systemId === "black-flag") return BLACK_FLAG_FEATURE_MODULES;
  if (systemId === "dnd5e") return DND5E_FEATURE_MODULES;
  return Object.freeze({});
}

function bootstrapSystemId() {
  const setupSystem = game.data?.system;
  return game.system?.id
    ?? setupSystem?.id
    ?? (typeof setupSystem === "string" ? setupSystem : null)
    ?? game.world?.system
    ?? null;
}

// Start loading immediately, but never await feature modules before the root
// lifecycle listeners have been registered. Foundry does not guarantee that
// a module entry point using top-level await finishes before it emits init.
// Each feature import remains isolated by loadStartupModule().
let features = new Map();
let loadedSystemId = null;
let featuresReady = Promise.resolve(features);

function loadFeatures(systemId) {
  if (!systemId || loadedSystemId === systemId) return featuresReady;
  loadedSystemId = systemId;
  const definitions = featureModulesForSystem(systemId);
  featuresReady = Promise.all(Object.entries(definitions).map(async ([id, path]) => (
    [id, await loadStartupModule(id, new URL(path, import.meta.url).href)]
  ))).then(loadedEntries => {
    features = new Map(loadedEntries);
    return features;
  });
  return featuresReady;
}

// Setup data is available before game.system in Foundry v14. Start imports as
// early as possible without assuming that the initialized System object exists.
void loadFeatures(bootstrapSystemId());

function featureExport(feature, name) {
  const callback = features.get(feature)?.[name];
  return typeof callback === "function" ? callback : null;
}

function step(id, feature, exportName) {
  const callback = featureExport(feature, exportName);
  return callback ? [id, callback] : null;
}

function compactSteps(steps) {
  return steps.filter(Boolean);
}

const MODULE_MENU_ORDER = new Map([
  ["help", 0], ["creatureBuilder", 10], ["compendiumTransfer", 20],
  ["characterLinkTools", 40], ["weaponCustomization", 50], ["argonCombatHud", 55], ["challengeHud", 56],
  ["itemDefaults", 60], ["playerActorFolders", 70], ["sessionRewards", 80]
]);
const MODULE_SETTING_ORDER = new Map([
  ["worldRole", 0], ["automaticTokenSizing", 10], ["tokenDistanceDisplay", 15], ["unpauseWithoutGM", 20],
  ["sessionHistoryEnabled", 30]
]);

function localConfigurationKey(key, prefix) {
  return key.slice(prefix.length);
}

function localizedConfigurationName(registry, key) {
  return game.i18n.localize(registry.get(key)?.name ?? key);
}

function reorderModuleEntries(registry, order, { configuredOnly = false } = {}) {
  const prefix = `${MODULE_ID}.`;
  const own = [...registry].filter(([key, value]) => (
    key.startsWith(prefix) && (!configuredOnly || value.config === true)
  ));
  if (!own.length) return;
  own.sort(([left], [right]) => {
    const leftRank = order.get(localConfigurationKey(left, prefix)) ?? 1000;
    const rightRank = order.get(localConfigurationKey(right, prefix)) ?? 1000;
    if (leftRank !== rightRank) return leftRank - rightRank;
    return localizedConfigurationName(registry, left)
      .localeCompare(localizedConfigurationName(registry, right), game.i18n.lang);
  });
  const ownKeys = new Set(own.map(([key]) => key));
  const ordered = [];
  let inserted = false;
  for (const entry of registry) {
    if (!ownKeys.has(entry[0])) ordered.push(entry);
    else if (!inserted) {
      ordered.push(...own);
      inserted = true;
    }
  }
  registry.clear();
  for (const [key, value] of ordered) registry.set(key, value);
}

function orderModuleMenus() {
  reorderModuleEntries(game.settings.menus, MODULE_MENU_ORDER);
  reorderModuleEntries(game.settings.settings, MODULE_SETTING_ORDER, { configuredOnly: true });
}

function foundationInitSteps() {
  return compactSteps([
    step("sessionTransfer", "sessionTransfer", "registerSessionTransfer")
  ]);
}

function initSteps() {
  return compactSteps([
    ["blackFlagCompatibility", installBlackFlagCompatibility],
    step("simpleTileTriggers", "simpleTileTriggers", "registerSimpleTileTriggers"),
    step("sceneItemLoot", "sceneItemLoot", "registerSceneItemLoot"),
    step("sceneActionHud", "sceneActionHud", "registerSceneActionHud"),
    step("commerce", "commerce", "registerCommerce"),
    step("chatTimestamps", "chatTimestamps", "installChatTimestamps"),
    step("compendiumUsability", "compendiumUsability", "installCompendiumUsability"),
    step("chatImagePopouts", "chatImagePopouts", "installChatImagePopouts"),
    step("chatMessageDeletion", "chatMessageDeletion", "registerChatMessageDeletion"),
    step("talentBackgrounds", "talentBackgrounds", "registerTalentBackgrounds"),
    step("characterOptionIndex", "characterOptionIndex", "registerCharacterOptionIndex"),
    step("spellScrolls", "spellScrolls", "installSpellScrollTools"),
    step("spellNameMarkers", "spellNameMarkers", "installSpellNameMarkers"),
    step("concentration", "concentration", "installConcentration"),
    step("effectGroups", "effectGroups", "installEffectGroups"),
    step("tokenHudMenu", "tokenHudMenu", "registerTokenHudMenu"),
    step("tokenPresets", "tokenPresets", "registerTokenPresets"),
    step("playerUnpause", "playerUnpause", "registerPlayerUnpause"),
    step("compendiumLibrary", "compendiumLibrary", "registerCompendiumLibrary"),
    step("dnd5eItemImporter", "dnd5eItemImporter", "registerDnd5eItemImporter"),
    step("weaponCustomization", "weaponCustomization", "registerWeaponCustomization"),
    step("mounting", "mounting", "registerMounting"),
    step("contestedActivity", "contestedActivity", "registerContestedActivity"),
    step("challengeManager", "challengeManager", "registerChallengeManager"),
    step("featurePool", "featurePool", "registerFeaturePoolIntegration"),
    step("tokenSizeSync", "tokenSizeSync", "registerTokenSizeSync"),
    step("tokenDistanceDisplay", "tokenDistanceDisplay", "registerTokenDistanceDisplay"),
    step("tokenPatrol", "tokenPatrol", "registerTokenPatrol"),
    step("creatureBuilder", "creatureBuilder", "registerCreatureBuilder"),
    step("actorDirectoryActivity", "actorDirectoryActivity", "registerActorDirectoryActivity"),
    step("help", "help", "registerHelp"),
    step("settingsCategories", "settingsCategories", "registerSettingsCategories"),
    step("namespaceMigration", "namespaceMigration", "registerNamespaceMigration"),
    step("migrationSettings", "migrations", "registerMigrationSettings"),
    ["downtime", registerDowntime],
    ["voidTaint", registerVoidTaint]
  ]);
}

function readyEarlySteps() {
  return compactSteps([
    step("moduleConflictWarning", "moduleConflicts", "activateModuleConflictWarning"),
    step("compatibilityActivation", "compatibility", "activateCompatibilityLayer"),
    step("moduleEventsActivation", "events", "activateModuleEvents"),
    step("simpleTileTriggerActivation", "simpleTileTriggers", "activateSimpleTileTriggers"),
    step("sceneItemLootActivation", "sceneItemLoot", "activateSceneItemLoot"),
    step("sceneActionHudActivation", "sceneActionHud", "activateSceneActionHud"),
    step("serverUpdateWarningActivation", "serverUpdateWarning", "activateServerUpdateWarning"),
    step("commerceActivation", "commerce", "activateCommerce"),
    step("schedulerActivation", "scheduler", "activateScheduler"),
    step("playerUnpauseActivation", "playerUnpause", "activatePlayerUnpause"),
    step("legacyNamespaceGuard", "namespaceMigration", "installLegacyNamespaceGuard"),
    ["moduleMenuOrder", orderModuleMenus],
    step("challengeManagerActivation", "challengeManager", "activateChallengeManager"),
    step("actorDirectoryActivityActivation", "actorDirectoryActivity", "activateActorDirectoryActivity"),
    step("tokenPresetSocket", "tokenPresets", "activateTokenPresetSocket"),
    step("tokenLightAuraSocket", "tokenLightAura", "activateTokenLightAuraSocket"),
    step("selectedTokenEffectsHud", "selectedTokenEffectsHud", "activateSelectedTokenEffectsHud"),
    step("tokenDistanceDisplayActivation", "tokenDistanceDisplay", "activateTokenDistanceDisplay"),
    step("tokenPatrolActivation", "tokenPatrol", "activateTokenPatrol"),
    step("mountingActivation", "mounting", "activateMounting")
  ]);
}

let initialization = Promise.resolve();

async function initializeModule() {
  await loadFeatures(game.system.id);
  if (game.system.id === "dnd5e") {
    const registerExporter = featureExport("dnd5eBundleExporter", "registerDnd5eBundleExporter");
    if (registerExporter) runStartupStep("dnd5eBundleExporter", registerExporter);
    return;
  }
  if (game.system.id !== "black-flag") return;
  runStartupSteps(foundationInitSteps());
  const installPhase = featureExport("compatibility", "installCompatibilityPhase");
  if (installPhase) {
    for (const phase of ["core", "documentUi", "optionalModules"]) {
      runStartupStep(`compatibility:${phase}`, () => installPhase(phase));
    }
  }
  runStartupSteps(initSteps());
  const registerLinkTools = featureExport("linkTools", "registerLinkTools");
  if (registerLinkTools) queueMicrotask(() => runStartupStep("linkTools", registerLinkTools));
}

async function activateModule() {
  await initialization;
  if (game.system.id !== "black-flag") return;
  runStartupSteps(readyEarlySteps());

  const migrateToolNamespace = featureExport("namespaceMigration", "migrateToolNamespace");
  const namespaceMigrationSucceeded = migrateToolNamespace
    ? await runStartupStepAsync("namespaceMigrationRun", migrateToolNamespace)
    : false;
  await runStartupStepAsync("downtimeActivation", activateDowntime);
  await runStartupStepAsync("voidTaintActivation", activateVoidTaint);
  const activateFeaturePool = featureExport("featurePool", "activateFeaturePoolIntegration");
  if (activateFeaturePool) await runStartupStepAsync("featurePoolActivation", activateFeaturePool);
  const createDrinks = featureExport("effectGroups", "createMagicalDrinkWorldItems");
  if (game.user.isGM && createDrinks) await runStartupStepAsync("magicalDrinkWorldItems", createDrinks);

  const moduleApi = game.modules.get(MODULE_ID)?.api;
  runStartupStep("diagnosticApi", () => Object.assign(moduleApi, {
    compatibility: features.get("compatibility")?.compatibilityApi,
    scheduler: features.get("scheduler")?.schedulerApi,
    startup: startupApi
  }));
  const exposeTransferApi = featureExport("compendiumTransfer", "exposeTransferApi");
  if (exposeTransferApi) runStartupStep("compendiumTransferApi", exposeTransferApi);
  const sessionApi = featureExport("sessionTransfer", "sessionTransferApi");
  if (sessionApi) runStartupStep("sessionTransferApi", () => Object.assign(moduleApi, sessionApi()));
  const creatureApi = featureExport("creatureBuilder", "creatureBuilderApi");
  if (creatureApi) runStartupStep("creatureBuilderApi", () => Object.assign(moduleApi, creatureApi()));
  runStartupStep("moduleApi", () => Object.assign(moduleApi, {
    toggleTokenLightAura: featureExport("tokenLightAura", "toggleTokenLightAura"),
    activityChaining: features.get("activityChaining")?.activityChainingApi,
    effectGroups: features.get("effectGroups")?.effectGroupsApi,
    characterCreationOverrides: features.get("characterCreation")?.characterCreationOverridesApi,
    weaponOptionActivities: features.get("weaponOptions")?.weaponOptionActivitiesApi,
    mounting: features.get("mounting")?.mountingApi
  }));

  const runMigrations = featureExport("migrations", "runMigrations");
  if (namespaceMigrationSucceeded && runMigrations) await runStartupStepAsync("migrations", runMigrations);
  featureExport("compatibility", "notifyCompatibilityFailures")?.();
  notifyStartupFailures();
}

// These listeners must remain synchronous top-level registrations. Moving an
// await above them can make Foundry emit init/ready before this module listens.
Hooks.once("init", () => {
  initialization = initializeModule().catch(error => {
    console.error(`${MODULE_ID} | Root initialization failed.`, error);
  });
});

Hooks.once("ready", () => {
  void activateModule().catch(error => {
    console.error(`${MODULE_ID} | Root activation failed.`, error);
    notifyStartupFailures();
  });
});
