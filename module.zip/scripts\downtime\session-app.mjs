import { MODULE_ID, SETTINGS } from "./constants.mjs";
import { WORLD_ROLES } from "../core/constants.mjs";
import { isOperationalGM } from "../core/permissions.mjs?v=3.7.8-permissions-1";
import { cleanupSessionImport, exportSession, exportSessionResult, importSession, importSessionResult, sessionImportHistory } from "../transfer/session-transfer.mjs?v=3.7.8-standard-effects-2";
import { DowntimeService } from "./downtime-service.mjs";
import { isActiveCharacter, isoWeekKey, levelFromMilestones, monthKey, passiveDowntimeConfig, playerCharacters, rewardForLevel, sessionRewardDetails, sessionRewards, SessionService, sessionProgress } from "./session-service.mjs";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export class SessionApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "downtime-manager-session",
    tag: "form",
    classes: ["downtime-manager", "downtime-session"],
    position: { width: 780, height: 820 },
    window: { title: "DOWNTIME_MANAGER.Session.Title", icon: "fa-solid fa-scroll", resizable: true },
    actions: {
      selectConnected: this.#selectConnected,
      selectTokens: this.#selectTokens,
      selectAll: this.#selectAll,
      selectNone: this.#selectNone,
      toggleInactive: this.#toggleInactive,
      save: this.#save,
      award: this.#award,
      settle: this.#settle,
      history: this.#history,
      correctSession: this.#correctSession,
      configureRewards: this.#configureRewards,
      workflowExportSession: this.#workflowExportSession,
      workflowImportSession: this.#workflowImportSession,
      workflowExportResult: this.#workflowExportResult,
      workflowImportResult: this.#workflowImportResult,
      workflowCleanup: this.#workflowCleanup,
      workflowCleanupHistory: this.#workflowCleanup,
      clearCleanedImportHistory: this.#clearCleanedImportHistory,
      workflowReset: this.#workflowReset,
      newSession: this.#newSession
    }
  };

  static PARTS = { main: { template: "modules/tov-feuerschwinge-tools/templates/downtime/session.hbs" } };

  _onRender(context, options) {
    super._onRender(context, options);
    if (!this._sessionWorldSized && game.settings.get(MODULE_ID, "worldRole") === WORLD_ROLES.SESSION) {
      this._sessionWorldSized = true;
      this.setPosition({ width: 780, height: "auto" });
    }
    const search = this.element.querySelector("[data-actor-search]");
    const applySearch = () => {
      this._actorSearch = String(search?.value ?? "").trim().toLocaleLowerCase();
      for (const row of this.element.querySelectorAll("[data-actor-search-text]")) {
        row.hidden = Boolean(this._actorSearch && !row.dataset.actorSearchText.toLocaleLowerCase().includes(this._actorSearch));
      }
    };
    if (search) {
      search.value = this._actorSearch ?? "";
      search.addEventListener("input", applySearch);
      applySearch();
    }
    const mode = this.element.querySelector('[name="selectionMode"]');
    const applyMode = () => {
      const playerMode = mode?.value === "player";
      this.element.querySelector("[data-character-selection]")?.toggleAttribute("hidden", playerMode);
      this.element.querySelector("[data-player-selection]")?.toggleAttribute("hidden", !playerMode);
    };
    mode?.addEventListener("change", applyMode);
    applyMode();
    for (const input of this.element.querySelectorAll('[name="players"]')) {
      input.addEventListener("change", () => {
        const uuids = String(input.dataset.actorUuids ?? "").split(",").filter(Boolean);
        for (const uuid of uuids) {
          const actorInput = this.element.querySelector(`[name="actors"][value="${CSS.escape(uuid)}"]`);
          if (actorInput) actorInput.checked = input.checked;
        }
      });
    }
    for (const input of this.element.querySelectorAll('[name="actors"]')) input.addEventListener("change", () => this.#syncPlayerSelection());
    for (const [fileName, action] of [
      ["workflowResultFile", "workflowImportResult"],
      ["workflowSessionFile", "workflowImportSession"]
    ]) {
      const fileInput = this.element.querySelector(`[name="${fileName}"]`);
      const button = this.element.querySelector(`[data-action="${action}"]`);
      if (!fileInput || !button) continue;
      const updateButton = () => button.disabled = !fileInput.files?.length;
      fileInput.addEventListener("change", updateButton);
      updateButton();
    }
  }

  async _prepareContext() {
    const active = game.settings.get(MODULE_ID, SETTINGS.ACTIVE_SESSION) ?? {};
    const selectedGm = active.gmUserId ?? (Object.keys(active).length === 0 ? game.user.id : "");
    const worldRole = game.settings.get(MODULE_ID, "worldRole");
    const workflowStatusKey = ["draft", "exported", "imported", "played", "returned", "awarded"].includes(active.status)
      ? active.status
      : "empty";
    const selected = new Set(active.actorUuids ?? []);
    const selectedTransferIds = new Set(active.participantTransferIds ?? []);
    const passiveConfig = passiveDowntimeConfig();
    const periodKey = passiveConfig.period === "week" ? isoWeekKey() : monthKey();
    const rewardConfig = sessionRewards();
    const columnCount = Math.max(0, ...rewardConfig.levels.map(level => level.items.length));
    const selectedColumns = new Set(Array.isArray(active.rewardColumns) ? active.rewardColumns.map(Number) : Array.from({ length: columnCount }, (_, index) => index));
    const rewardColumns = [];
    for (let index = 0; index < columnCount; index++) {
      const entries = rewardConfig.levels.map(level => level.items[index]).filter(Boolean);
      const documents = [];
      for (const entry of entries) {
        const document = await fromUuid(entry.uuid).catch(() => null);
        if (document && !documents.some(existing => existing.uuid === document.uuid)) documents.push(document);
      }
      rewardColumns.push({ index, selected: selectedColumns.has(index), name: documents.map(document => document.name).join(" / ") || game.i18n.format("DOWNTIME_MANAGER.Session.RewardColumn", { column: index + 1 }), img: documents[0]?.img ?? "icons/svg/mystery-man.svg" });
    }
    const actors = [];
    const guildActors = playerCharacters();
    const visibleGuildActors = guildActors.filter(actor => {
      const transferId = actor.getFlag(MODULE_ID, "transfer")?.id
        ?? `world:${game.world.id}:Actor:${actor.id}`;
      return this._showInactive || isActiveCharacter(actor)
        || selected.has(actor.uuid) || selectedTransferIds.has(transferId);
    });
    for (const actor of visibleGuildActors) {
      const progress = sessionProgress(actor);
      const level = levelFromMilestones(progress.milestones);
      const reward = rewardForLevel(level);
      const details = await sessionRewardDetails(reward, Number(active.multiplier ?? 1));
      const transferId = actor.getFlag(MODULE_ID, "transfer")?.id
        ?? `world:${game.world.id}:Actor:${actor.id}`;
      actors.push({
        uuid: actor.uuid, name: actor.name, img: actor.img, level,
        folder: actor.folder ? SessionApp.#folderPath(actor.folder) : game.i18n.localize("TOVF.Transfer.Root"),
        selected: selected.has(actor.uuid) || selectedTransferIds.has(transferId), downtime: DowntimeService.get(actor),
        rewardItems: details.items.map(item => ({ ...item, selected: selectedColumns.has(item.columnIndex) })),
        milestones: progress.milestones,
        passive: Number(progress.passiveDowntime?.[periodKey] ?? 0),
        characterActive: isActiveCharacter(actor)
      });
    }
    const actorUuids = new Set(actors.map(actor => actor.uuid));
    const selectedActorUuids = new Set(actors.filter(actor => actor.selected).map(actor => actor.uuid));
    const players = game.users.filter(user => !user.isGM).map(user => {
      const owned = guildActors.filter(actor => actorUuids.has(actor.uuid) && (
        (user.character?.id ?? user.character) === actor.id
        || actor.testUserPermission(user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)
      ));
      return {
        id: user.id,
        name: user.name,
        active: user.active,
        actorUuids: owned.map(actor => actor.uuid).join(","),
        characters: owned.map(actor => actor.name).join(", "),
        selected: owned.length > 0 && owned.every(actor => selectedActorUuids.has(actor.uuid)),
        searchText: `${user.name} ${owned.map(actor => actor.name).join(" ")}`
      };
    }).filter(player => player.actorUuids);
    const sessionParticipants = (active.actorUuids ?? []).map(uuid => game.actors.get(String(uuid).split(".").at(-1)))
      .filter(Boolean)
      .map(actor => {
        const owners = game.users.filter(user => !user.isGM && (
          String(user.character?.id ?? user.character ?? "") === actor.id
          || actor.testUserPermission(user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)
        ));
        return {
          uuid: actor.uuid,
          name: actor.name,
          img: actor.img,
          players: owners.map(user => user.name).join(", ") || game.i18n.localize("DOWNTIME_MANAGER.Common.None"),
          online: owners.some(user => user.active)
        };
      });
    const importHistory = worldRole === WORLD_ROLES.SESSION ? sessionImportHistory().slice().reverse().map(entry => ({
      ...entry,
      date: new Intl.DateTimeFormat(game.i18n.lang, { dateStyle: "medium", timeStyle: "short" }).format(new Date(entry.importedAt)),
      cleanedDate: entry.cleanedAt ? new Intl.DateTimeFormat(game.i18n.lang, { dateStyle: "medium", timeStyle: "short" }).format(new Date(entry.cleanedAt)) : "",
      actorCount: entry.importedContent?.actorUuids?.length ?? 0,
      userCount: entry.importedContent?.userIds?.length ?? 0,
      cleaned: Boolean(entry.cleanedAt)
    })) : [];
    const cleanedImports = importHistory.filter(entry => entry.cleaned);
    return {
      active,
      sessionOverview: {
        description: String(active.summary ?? active.description ?? "").trim(),
        participants: sessionParticipants
      },
      gmUsers: game.users.filter(isOperationalGM).map(u => ({ id: u.id, name: u.name, selected: u.id === selectedGm })),
      isPrimaryWorld: worldRole === WORLD_ROLES.PRIMARY,
      isSessionWorld: worldRole === WORLD_ROLES.SESSION,
      activeImports: importHistory.filter(entry => !entry.cleaned),
      cleanedImports: cleanedImports.slice(0, 10),
      cleanedImportCount: cleanedImports.length,
      workflowStatus: game.i18n.localize(`DOWNTIME_MANAGER.Session.Workflow.Statuses.${workflowStatusKey}`),
      workflowReturned: active.status === "returned",
      workflowHasSession: Boolean(active.id),
      workflowCanExportSession: worldRole === WORLD_ROLES.PRIMARY && !["returned", "awarded"].includes(active.status),
      workflowCanImportResult: worldRole === WORLD_ROLES.PRIMARY,
      workflowCanImportSession: worldRole === WORLD_ROLES.SESSION,
      workflowCanExportResult: worldRole === WORLD_ROLES.SESSION && ["imported", "played"].includes(active.status),
      workflowCanCleanup: worldRole === WORLD_ROLES.SESSION && Boolean(active.id),
      canSaveSession: worldRole === WORLD_ROLES.PRIMARY && !["exported", "returned", "awarded"].includes(active.status),
      canAwardSession: worldRole === WORLD_ROLES.PRIMARY && !["exported", "awarded"].includes(active.status),
      periodKey,
      passiveWeekly: passiveConfig.period === "week",
      historyEnabled: game.settings.get(MODULE_ID, SETTINGS.SESSION_HISTORY_ENABLED),
      awarded: active.status === "awarded",
      actors,
      showInactive: Boolean(this._showInactive),
      hasInactive: guildActors.some(actor => !isActiveCharacter(actor)),
      connectedPlayers: players.filter(player => player.active),
      otherPlayers: players.filter(player => !player.active),
      rewardColumns,
      awardMilestones: active.awardMilestones !== false,
      multipliers: [1, 1.5, 2].map(value => ({ value, selected: Number(active.multiplier ?? 1) === value })),
      includeTransferScenes: active.includeTransferScenes === true
    };
  }

  static #folderPath(folder) {
    const names = [];
    for (let current = folder; current; current = current.folder) names.unshift(current.name);
    return names.join(" / ");
  }

  #syncPlayerSelection() {
    for (const input of this.element.querySelectorAll('[name="players"]')) {
      const uuids = String(input.dataset.actorUuids ?? "").split(",").filter(Boolean);
      input.checked = uuids.length > 0 && uuids.every(uuid => this.element.querySelector(`[name="actors"][value="${CSS.escape(uuid)}"]`)?.checked);
    }
  }

  #setVisibleSelection(checked) {
    const playerMode = this.element.querySelector('[name="selectionMode"]')?.value === "player";
    const inputs = this.element.querySelectorAll(playerMode ? '[name="players"]' : '[name="actors"]');
    for (const input of inputs) {
      if (input.closest("[data-actor-search-text]")?.hidden) continue;
      input.checked = checked;
      if (playerMode) {
        for (const uuid of String(input.dataset.actorUuids ?? "").split(",").filter(Boolean)) {
          const actorInput = this.element.querySelector(`[name="actors"][value="${CSS.escape(uuid)}"]`);
          if (actorInput) actorInput.checked = checked;
        }
      }
    }
    this.#syncPlayerSelection();
  }

  #formState() {
    return {
      title: this.element.querySelector('[name="title"]')?.value.trim() ?? "",
      gmUserId: this.element.querySelector('[name="sessionGm"]')?.value ?? "",
      summary: this.element.querySelector('[name="summary"]')?.value.trim() ?? "",
      multiplier: Number(this.element.querySelector('[name="multiplier"]')?.value ?? 1),
      actorUuids: Array.from(this.element.querySelectorAll('[name="actors"]:checked')).map(input => input.value),
      rewardColumns: Array.from(this.element.querySelectorAll('[name="rewardColumns"]:checked')).map(input => Number(input.value)),
      awardMilestones: Boolean(this.element.querySelector('[name="awardMilestones"]')?.checked),
      includeTransferScenes: Boolean(this.element.querySelector('[name="includeTransferScenes"]')?.checked)
    };
  }

  static #selectConnected(event) {
    event.preventDefault();
    const connected = game.users.filter(user => user.active && !user.isGM);
    const selected = new Set(game.actors.filter(actor => connected.some(user => (
      (user.character?.id ?? user.character) === actor.id
      || actor.testUserPermission(user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)
    ))).map(actor => actor.uuid));
    this.element.querySelectorAll('[name="actors"]').forEach(input => input.checked = selected.has(input.value));
    this.#syncPlayerSelection();
  }

  static #selectTokens(event) {
    event.preventDefault();
    const selected = new Set((canvas?.tokens?.controlled ?? []).map(token => token.actor?.uuid).filter(Boolean));
    this.element.querySelectorAll('[name="actors"]').forEach(input => input.checked = selected.has(input.value));
    this.#syncPlayerSelection();
  }

  static #selectAll(event) { event.preventDefault(); this.#setVisibleSelection(true); }
  static #selectNone(event) { event.preventDefault(); this.#setVisibleSelection(false); }
  static #toggleInactive(event) {
    event.preventDefault();
    this._showInactive = !this._showInactive;
    this.render();
  }

  static async #save(event) {
    event.preventDefault();
    const state = this.#formState();
    if (!state.actorUuids.length || !state.title) return ui.notifications.warn(game.i18n.localize("DOWNTIME_MANAGER.Session.Errors.Required"));
    const previous = game.settings.get(MODULE_ID, SETTINGS.ACTIVE_SESSION) ?? {};
    if (["exported", "returned"].includes(previous.status)) return ui.notifications.warn(game.i18n.localize("DOWNTIME_MANAGER.Session.Workflow.Locked"));
    if (previous.status === "awarded") return ui.notifications.warn(game.i18n.localize("DOWNTIME_MANAGER.Session.Errors.StartNew"));
    await game.settings.set(MODULE_ID, SETTINGS.ACTIVE_SESSION, { ...state, id: previous.id ?? foundry.utils.randomID(), startedAt: previous.startedAt ?? Date.now(), status: "draft" });
    ui.notifications.info(game.i18n.localize("DOWNTIME_MANAGER.Session.Saved"));
    await this.render({ force: true });
  }

  static async #workflowExportSession(event) {
    event.preventDefault();
    const state = this.#formState();
    if (!state.actorUuids.length || !state.title) return ui.notifications.warn(game.i18n.localize("DOWNTIME_MANAGER.Session.Errors.Required"));
    const previous = game.settings.get(MODULE_ID, SETTINGS.ACTIVE_SESSION) ?? {};
    const active = {
      ...previous,
      ...state,
      id: previous.id ?? foundry.utils.randomID(),
      startedAt: previous.startedAt ?? Date.now(),
      status: "draft"
    };
    await game.settings.set(MODULE_ID, SETTINGS.ACTIVE_SESSION, active);
    const actorIds = state.actorUuids.map(uuid => fromUuidSync(uuid)?.id).filter(Boolean);
    const bundle = await exportSession(actorIds, { session: active, includeTransferScenes: state.includeTransferScenes });
    if (!bundle) return;
    const participantTransferIds = new Set(bundle.session?.participantTransferIds ?? []);
    const participantUuids = game.actors
      .filter(actor => participantTransferIds.has(actor.getFlag(MODULE_ID, "transfer")?.id
        ?? `world:${game.world.id}:Actor:${actor.id}`))
      .map(actor => actor.uuid);
    await game.settings.set(MODULE_ID, SETTINGS.ACTIVE_SESSION, {
      ...active,
      actorUuids: participantUuids,
      participantTransferIds: [...participantTransferIds],
      status: "exported",
      exportedAt: Date.now()
    });
    await this.render({ force: true });
  }

  static async #workflowImportSession(event) {
    event.preventDefault();
    const file = this.element.querySelector('[name="workflowSessionFile"]')?.files?.[0];
    try {
      await importSession(file);
      await this.render({ force: true });
    } catch (error) {
      console.error(`${MODULE_ID} | Guided session import failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #workflowExportResult(event) {
    event.preventDefault();
    try {
      const result = await exportSessionResult();
      if (result) await cleanupSessionImport();
      await this.render({ force: true });
    } catch (error) {
      console.error(`${MODULE_ID} | Guided session result export failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #workflowImportResult(event) {
    event.preventDefault();
    const file = this.element.querySelector('[name="workflowResultFile"]')?.files?.[0];
    try {
      await importSessionResult(file);
      await this.render({ force: true });
    } catch (error) {
      console.error(`${MODULE_ID} | Guided session result import failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #workflowCleanup(event, target) {
    event.preventDefault();
    try {
      if (await cleanupSessionImport(target?.dataset?.importId ?? "")) await this.render({ force: true });
    } catch (error) {
      console.error(`${MODULE_ID} | Session cleanup failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #clearCleanedImportHistory(event) {
    event.preventDefault();
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Bereinigungsverlauf leeren" },
      content: "<p>Alle bereits bereinigten Importeinträge aus dem Verlauf entfernen? Aktive Importe und Weltdokumente bleiben unverändert.</p>"
    });
    if (!confirmed) return;
    const history = foundry.utils.deepClone(game.settings.get(MODULE_ID, SETTINGS.SESSION_IMPORT_HISTORY) ?? { schemaVersion: 1, entries: [] });
    history.entries = (history.entries ?? []).filter(entry => !entry.cleanedAt);
    await game.settings.set(MODULE_ID, SETTINGS.SESSION_IMPORT_HISTORY, history);
    ui.notifications.info("Der Bereinigungsverlauf wurde geleert.");
    await this.render({ force: true });
  }

  static async #workflowReset(event) {
    event.preventDefault();
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("DOWNTIME_MANAGER.Session.Workflow.NewSession") },
      content: `<p>${game.i18n.localize("DOWNTIME_MANAGER.Session.Workflow.ResetConfirm")}</p>`
    });
    if (!confirmed) return;
    await game.settings.set(MODULE_ID, SETTINGS.ACTIVE_SESSION, {});
    ui.notifications.info(game.i18n.localize("DOWNTIME_MANAGER.Session.Workflow.ResetComplete"));
    await this.render({ force: true });
  }

  static async #award(event) {
    event.preventDefault();
    const form = this.#formState();
    const stored = game.settings.get(MODULE_ID, SETTINGS.ACTIVE_SESSION) ?? {};
    if (!form.actorUuids.length || !form.title) return ui.notifications.warn(game.i18n.localize("DOWNTIME_MANAGER.Session.Errors.Required"));
    const active = { ...stored, ...form, id: stored.id ?? foundry.utils.randomID(), title: form.title || game.i18n.localize("DOWNTIME_MANAGER.Session.Untitled") };
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("DOWNTIME_MANAGER.Session.Award") },
      content: `<p>${game.i18n.format("DOWNTIME_MANAGER.Session.AwardConfirm", { count: form.actorUuids.length })}</p>`
    });
    if (!confirmed) return;
    try {
      await SessionService.award({ active, actorUuids: form.actorUuids, multiplier: form.multiplier, rewardColumns: form.rewardColumns, awardMilestones: form.awardMilestones });
      ui.notifications.info(game.i18n.localize("DOWNTIME_MANAGER.Session.Awarded"));
      await this.render({ force: true });
    } catch (error) {
      console.error(`${MODULE_ID} | Session reward failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #settle(event) {
    event.preventDefault();
    const period = this.element.querySelector('[name="period"]')?.value || (passiveDowntimeConfig().period === "week" ? isoWeekKey() : monthKey());
    const confirmed = await foundry.applications.api.DialogV2.confirm({ window: { title: game.i18n.localize("DOWNTIME_MANAGER.Session.Settle") }, content: `<p>${game.i18n.format("DOWNTIME_MANAGER.Session.SettleConfirm", { month: period })}</p>` });
    if (!confirmed) return;
    try {
      const record = await SessionService.settle(period);
      ui.notifications.info(game.i18n.format("DOWNTIME_MANAGER.Session.Settled", { count: record.recipients.length }));
      await this.render({ force: true });
    } catch (error) {
      console.error(`${MODULE_ID} | Passive downtime settlement failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static #history(event) { event.preventDefault(); return SessionService.openHistory(); }
  static async #correctSession(event) {
    event.preventDefault();
    const entries = SessionService.historyEntries().filter(entry => entry.id && Array.isArray(entry.participants)).slice().reverse();
    if (!entries.length) return ui.notifications.warn(game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Empty"));
    const options = entries.map(entry => `<option value="${foundry.utils.escapeHTML(String(entry.id))}">${foundry.utils.escapeHTML(entry.title)} · ${new Date(entry.awardedAt).toLocaleString()}</option>`).join("");
    const recordId = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Title") },
      content: `<div class="standard-form"><label><span>${game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Session")}</span><select name="recordId">${options}</select></label></div>`,
      ok: { label: game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Select"), callback: (_event, button) => new FormData(button.form).get("recordId") },
      rejectClose: false
    });
    if (!recordId) return;
    const correction = await SessionService.correctionDefaults(recordId);
    const rows = correction.actors.map(actor => `<label class="sc-session-correction-row"><input type="checkbox" name="actors" value="${foundry.utils.escapeHTML(actor.actorUuid)}" ${actor.selected ? "checked" : ""}><strong>${foundry.utils.escapeHTML(actor.actorName)}</strong><span>${game.i18n.localize("DOWNTIME_MANAGER.Currency.GP")}</span><input type="number" name="gold.${foundry.utils.escapeHTML(actor.actorUuid)}" value="${actor.gold}" min="0" step="any"></label>`).join("");
    const result = await foundry.applications.api.DialogV2.prompt({
      classes: ["downtime-manager", "sc-session-correction-dialog"],
      window: { title: game.i18n.format("DOWNTIME_MANAGER.Session.Correction.EditTitle", { title: correction.record.title }) },
      position: { width: 620, height: 700 },
      content: `<div class="standard-form"><p class="notes">${game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Hint")}</p><div class="sc-session-correction-list">${rows}</div></div>`,
      ok: { label: game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Apply"), callback: (_event, button) => {
        const data = new FormData(button.form);
        return { actorUuids: data.getAll("actors"), goldByActor: Object.fromEntries(correction.actors.map(actor => [actor.actorUuid, data.get(`gold.${actor.actorUuid}`)])) };
      } },
      rejectClose: false
    });
    if (!result) return;
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Title") },
      content: `<p>${game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Confirm")}</p>`
    });
    if (!confirmed) return;
    try {
      await SessionService.correctSession({ recordId, ...result });
      ui.notifications.info(game.i18n.localize("DOWNTIME_MANAGER.Session.Correction.Complete"));
      await this.render({ force: true });
    } catch (error) {
      console.error(`${MODULE_ID} | Session correction failed`, error);
      ui.notifications.error(error.message);
    }
  }
  static async #configureRewards(event) { event.preventDefault(); const { SessionRewardConfigApp } = await import("./session-reward-config-app.mjs"); new SessionRewardConfigApp().render(true); }
  static async #newSession(event) {
    event.preventDefault();
    const active = game.settings.get(MODULE_ID, SETTINGS.ACTIVE_SESSION) ?? {};
    if (active.id && active.status !== "awarded") {
      let timer = null;
      const confirmed = await foundry.applications.api.DialogV2.wait({
        classes: ["downtime-manager", "sc-new-session-warning"],
        window: { title: game.i18n.localize("DOWNTIME_MANAGER.Session.NewWarning.Title") },
        content: `<div class="notification warning"><p><strong>${game.i18n.localize("DOWNTIME_MANAGER.Session.NewWarning.Heading")}</strong></p><p>${game.i18n.localize("DOWNTIME_MANAGER.Session.NewWarning.Text")}</p></div>`,
        buttons: [
          { action: "cancel", label: game.i18n.localize("Cancel"), callback: () => false },
          { action: "confirm", icon: "fa-solid fa-triangle-exclamation", label: game.i18n.format("DOWNTIME_MANAGER.Session.NewWarning.Wait", { seconds: 5 }), callback: () => true }
        ],
        render: (_renderEvent, dialog) => {
          const button = dialog.element.querySelector('button[data-action="confirm"]');
          if (!button) return;
          button.disabled = true;
          let remaining = 5;
          timer = setInterval(() => {
            remaining -= 1;
            if (remaining > 0) button.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${game.i18n.format("DOWNTIME_MANAGER.Session.NewWarning.Wait", { seconds: remaining })}`;
            else { clearInterval(timer); timer = null; button.disabled = false; button.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${game.i18n.localize("DOWNTIME_MANAGER.Session.NewWarning.Confirm")}`; }
          }, 1000);
        },
        rejectClose: false
      });
      if (timer) clearInterval(timer);
      if (!confirmed) return;
    }
    await game.settings.set(MODULE_ID, SETTINGS.ACTIVE_SESSION, { gmUserId: game.user.id });
    await this.render({ force: true });
  }
}
