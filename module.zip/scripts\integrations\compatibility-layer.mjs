import { MODULE_ID } from "../core/constants.mjs";

const DEFINITIONS = Object.freeze({
  core: [
    ["mountedTokenDragging", "./mounting-token-drag.mjs?v=3.10.1-mounted-drag-1", "installMountedTokenDragging"],
    ["combatTurnActivities", "./combat-turn-activities.mjs", "installCombatTurnActivities"],
    ["gearCategories", "./gear-categories.mjs", "installGearCategories"],
    ["characterCreation", "./character-creation-overrides.mjs?v=3.9.3-subclass-deduplication-1", "installCharacterCreationOverrides"],
    ["weaponOptionActivities", "./weapon-option-activities.mjs?v=3.2.4-tooltip-links-2", "installWeaponOptionActivities"],
    ["activityChaining", "../activity-chaining.mjs?v=3.3.1-follow-up-filter-2", "installActivityChaining"],
    ["toolAbility", "./tool-ability.mjs", "installToolAbilitySelection"],
    ["toolProficiencyRemoval", "./tool-proficiency-removal.mjs", "installToolProficiencyRemoval"],
    ["spellLearningPersistence", "./spell-learning-persistence.mjs", "installSpellLearningPersistence"],
    ["theurgeSpellcasting", "./theurge-spellcasting.mjs?v=3.11.5-theurge-sources-1", "installTheurgeSpellcasting"]
  ],
  documentUi: [
    ["customBackground", "./custom-background.mjs?v=3.8.5-custom-background-17", "installCustomBackground"],
    ["characterOptionFilters", "./character-option-filters.mjs?v=3.9.3-character-option-filters-1", "installCharacterOptionFilters"],
    ["classSelectionLayout", "./class-selection-layout.mjs", "installClassSelectionLayout"],
    ["featureSelectionLayout", "./feature-selection-layout.mjs?v=3.11.5-talent-prerequisite-groups-1", "installFeatureSelectionLayout"],
    ["spellManager", "./spell-manager.mjs?v=3.11.5-theurge-source-selection-1", "installSpellManager"],
    ["multiLevelDown", "./multi-level-down.mjs", "installMultiLevelDown"],
    ["activeEffectChangesUi", "../active-effect-changes-ui.mjs?v=3.7.8-actor-effect-delete-3", "installActiveEffectChangesUi"],
    ["enchantActivityUi", "./enchant-activity-ui.mjs?v=3.8.5-enchant-library-5", "installEnchantActivityUi"],
    ["spellcastingFilterControls", "./spellcasting-filter-controls.mjs?v=3.8.5-spell-filter-controls-1", "installSpellcastingFilterControls"],
    ["skillListControls", "./skill-list-controls.mjs?v=3.11.3-ability-design-v360-12", "installSkillListControls"]
  ],
  optionalModules: [
    ["luckRerollDiceSoNice", "./luck-reroll-dice-so-nice.mjs?v=3.11.5-luck-reroll-dsn-1", "installLuckRerollDiceSoNice"],
    ["argon", "./argon-black-flag-compatibility.mjs?v=3.9.3-unbound-item-guard-1", "installArgonBlackFlagCompatibility"]
  ],
  ready: [
    ["summon", "../summon-compat.mjs?v=3.6.2-character-summon-folder-1", "activateSummonCompatibility"]
  ]
});

const statuses = new Map(Object.entries(DEFINITIONS).flatMap(([phase, definitions]) => (
  definitions.map(([id]) => [id, { id, phase, status: "pending" }])
)));
const installers = new Map();
const installedPhases = new Set();
const notifiedFailures = new Set();
let failureNotificationRegistered = false;

function serializeError(error) {
  return {
    name: String(error?.name ?? "Error"),
    message: String(error?.message ?? error ?? "Unknown error")
  };
}

function notifyFailuresOnReady() {
  if (failureNotificationRegistered) return;
  failureNotificationRegistered = true;
  Hooks.once("ready", notifyCompatibilityFailures);
}

await Promise.all(Object.entries(DEFINITIONS).flatMap(([phase, definitions]) => (
  definitions.map(async ([id, path, exportName]) => {
    const startedAt = Date.now();
    try {
      const module = await import(path);
      const installer = module?.[exportName];
      if (typeof installer !== "function") throw new Error(`Missing export ${exportName}.`);
      installers.set(id, installer);
      statuses.set(id, { id, phase, status: "loaded", durationMs: Date.now() - startedAt });
    } catch (error) {
      statuses.set(id, {
        id,
        phase,
        status: "failed",
        durationMs: Date.now() - startedAt,
        error: serializeError(error)
      });
      console.error(`${MODULE_ID} | Compatibility integration "${id}" failed to load.`, error);
      notifyFailuresOnReady();
    }
  })
)));

export function notifyCompatibilityFailures() {
  const failed = [...statuses.values()].filter(entry => (
    ["failed", "incompatible"].includes(entry.status) && !notifiedFailures.has(entry.id)
  ));
  if (!failed.length) return;
  for (const entry of failed) notifiedFailures.add(entry.id);
  ui.notifications.error(game.i18n.format("TOVF.Compatibility.InstallFailed", {
    integrations: failed.map(entry => entry.id).join(", ")
  }), { permanent: true });
}

function installIntegration(id, phase, installer) {
  const startedAt = Date.now();
  try {
    const result = installer();
    const outcome = result && typeof result === "object"
      ? result
      : { status: result === false ? "skipped" : "completed" };
    statuses.set(id, {
      id,
      phase,
      ...outcome,
      status: outcome.status ?? "completed",
      durationMs: Date.now() - startedAt
    });
    if (outcome.status === "incompatible") {
      console.error(`${MODULE_ID} | Compatibility integration "${id}" is incompatible: ${outcome.reason ?? "required API missing"}.`);
      notifyFailuresOnReady();
    }
  } catch (error) {
    statuses.set(id, {
      id,
      phase,
      status: "failed",
      durationMs: Date.now() - startedAt,
      error: serializeError(error)
    });
    console.error(`${MODULE_ID} | Compatibility integration "${id}" failed to install.`, error);
    notifyFailuresOnReady();
  }
}

/** Install one compatibility phase without allowing a broken integration to block the rest. */
export function installCompatibilityPhase(phase) {
  if (installedPhases.has(phase) || game.system.id !== "black-flag") return;
  const definitions = DEFINITIONS[phase];
  if (!definitions) throw new Error(`Unknown compatibility phase: ${phase}`);
  installedPhases.add(phase);
  for (const [id] of definitions) {
    const installer = installers.get(id);
    if (installer) installIntegration(id, phase, installer);
  }
}

/** Activate compatibility work which requires initialized World data. */
export function activateCompatibilityLayer() {
  installCompatibilityPhase("ready");
}

/** Serializable diagnostic snapshot for support and console inspection. */
export function compatibilityReport() {
  return {
    foundryVersion: game.version,
    system: { id: game.system.id, version: game.system.version },
    moduleVersion: game.modules.get(MODULE_ID)?.version ?? "",
    integrations: [...statuses.values()].map(entry => foundry.utils.deepClone(entry))
  };
}

export const compatibilityApi = Object.freeze({ report: compatibilityReport });
