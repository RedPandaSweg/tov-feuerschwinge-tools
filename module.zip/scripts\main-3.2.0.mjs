import "./main.mjs";
