import { uiText } from "../core/localization.mjs";
import { MODULE_ID } from "../core/constants.mjs";
import { changeCurrency, itemQuantity, quantityUpdate, setItemQuantity, validateCurrencyChange } from "./currency.mjs?v=3.5.0-item-quantity-1";

const locks = new Map();

async function locked(keys, operation) {
  const ordered = [...new Set(keys)].sort();
  while (ordered.some(key => locks.has(key))) {
    await Promise.race(ordered.map(key => locks.get(key)).filter(Boolean));
  }
  let release;
  const promise = new Promise(resolve => release = resolve);
  for (const key of ordered) locks.set(key, promise);
  try { return await operation(); }
  finally {
    for (const key of ordered) if (locks.get(key) === promise) locks.delete(key);
    release();
  }
}

export function cleanTransferredItem(item, quantity) {
  const data = item.toObject();
  delete data._id;
  delete data._stats;
  setItemQuantity(data, quantity);
  data.system.container = null;
  foundry.utils.deleteProperty(data, "flags.core.sourceId");
  if (data.flags?.["black-flag"]?.relationship?.attuned) data.flags["black-flag"].relationship.attuned = false;
  const aliases = { platinum: "pp", gold: "gp", silver: "sp", copper: "cp" };
  const denomination = String(data.system?.price?.denomination ?? "").toLowerCase();
  if (data.system?.price && aliases[denomination]) data.system.price.denomination = aliases[denomination];
  return data;
}

function stackSignature(item, { merchantStock = false } = {}) {
  const data = item?.toObject ? item.toObject() : foundry.utils.deepClone(item);
  delete data._id;
  delete data._stats;
  delete data.sort;
  delete data.folder;
  delete data.ownership;
  foundry.utils.deleteProperty(data, "system.quantity");
  foundry.utils.deleteProperty(data, "system.container");
  foundry.utils.deleteProperty(data, "flags.core.sourceId");
  if (merchantStock) {
    foundry.utils.deleteProperty(data, `flags.${MODULE_ID}.merchantItem`);
    if (foundry.utils.isEmpty(data.flags?.[MODULE_ID] ?? {})) delete data.flags?.[MODULE_ID];
  }
  if (foundry.utils.isEmpty(data.flags ?? {})) delete data.flags;
  return JSON.stringify(data);
}

export function findStackableItem(actor, itemData, { stackWeapons = false, merchantStock = false } = {}) {
  if (itemData.type === "weapon" && !stackWeapons) return null;
  const sourceUuid = String(itemData.flags?.[MODULE_ID]?.merchantItem?.sourceUuid ?? "");
  if (sourceUuid) {
    const sourced = actor.items.find(item => item.type === itemData.type
      && item.getFlag(MODULE_ID, "merchantItem")?.sourceUuid === sourceUuid);
    if (sourced) return sourced;
    if (merchantStock) {
      const identifier = String(itemData.system?.identifier ?? "").trim();
      const legacy = actor.items.find(item => item.type === itemData.type && (identifier
        ? String(item.system?.identifier ?? "").trim() === identifier
        : item.name.trim().localeCompare(itemData.name.trim(), undefined, { sensitivity: "base" }) === 0));
      if (legacy) return legacy;
    }
  }
  const signature = stackSignature(itemData, { merchantStock });
  return actor.items.find(item => stackSignature(item, { merchantStock }) === signature) ?? null;
}

export async function addItem(actor, itemData, quantity, { stackWeapons = false, merchantStock = false } = {}) {
  const existing = findStackableItem(actor, itemData, { stackWeapons, merchantStock });
  if (existing) {
    await existing.update(quantityUpdate(existing, itemQuantity(existing) + quantity));
    return existing;
  }
  const data = foundry.utils.deepClone(itemData);
  setItemQuantity(data, quantity);
  const [created] = await actor.createEmbeddedDocuments("Item", [data]);
  return created;
}

export async function removeItem(actor, item, quantity) {
  const current = itemQuantity(item);
  if (!(quantity > 0) || current < quantity) throw new Error(uiText("TOVF.Interface.P0IsNotAvailableInSufficientQuantity_91720d", "{p0} ist nicht in ausreichender Menge vorhanden.", { p0: (item.name) }));
  if (current === quantity) await actor.deleteEmbeddedDocuments("Item", [item.id]);
  else await actor.updateEmbeddedDocuments("Item", [quantityUpdate(item, current - quantity)]);
}

async function transferItemUnlocked({ source, target, itemId, quantity = 1, keepSource = false }) {
  quantity = Math.max(1, Math.floor(Number(quantity) || 1));
  const item = source.items.get(itemId);
  if (!item) throw new Error(uiText("TOVF.Interface.TheItemWasNotFound_56f5aa", "Der Gegenstand wurde nicht gefunden."));
  if (item.type === "currency") throw new Error(uiText("TOVF.Interface.CurrencyIsTransferredUsingTheMoneyAmount_5b306f", "Währung wird über den Geldbetrag übertragen."));
  if (itemQuantity(item) < quantity && !keepSource) throw new Error("Der Bestand reicht nicht aus.");
  const data = cleanTransferredItem(item, quantity);
  if (!keepSource) await removeItem(source, item, quantity);
  try { return await addItem(target, data, quantity); }
  catch (error) {
    if (!keepSource) await addItem(source, data, quantity).catch(() => {});
    throw error;
  }
}

export async function transferItem(options) {
  return locked([options.source.uuid, options.target.uuid], () => transferItemUnlocked(options));
}

export async function exchange({ fromActor, toActor, fromCopper = 0, toCopper = 0, fromItems = [], toItems = [] }) {
  return locked([fromActor.uuid, toActor.uuid], async () => {
    validateCurrencyChange(fromActor, -fromCopper + toCopper);
    validateCurrencyChange(toActor, -toCopper + fromCopper);
    for (const entry of fromItems) {
      const item = fromActor.items.get(entry.itemId);
      if (!item || itemQuantity(item) < entry.quantity) throw new Error(uiText("TOVF.Interface.AnOfferedItemIsNoLongerAvailable_96b146", "Ein angebotener Gegenstand ist nicht mehr verfügbar."));
    }
    for (const entry of toItems) {
      const item = toActor.items.get(entry.itemId);
      if (!item || itemQuantity(item) < entry.quantity) throw new Error(uiText("TOVF.Interface.ARequestedItemIsNoLongerAvailable_2827d7", "Ein angeforderter Gegenstand ist nicht mehr verfügbar."));
    }
    if (fromCopper !== toCopper) {
      await changeCurrency(fromActor, -fromCopper + toCopper);
      try { await changeCurrency(toActor, -toCopper + fromCopper); }
      catch (error) {
        await changeCurrency(fromActor, fromCopper - toCopper).catch(() => {});
        throw error;
      }
    }
    for (const entry of fromItems) await transferItemUnlocked({ source: fromActor, target: toActor, ...entry });
    for (const entry of toItems) await transferItemUnlocked({ source: toActor, target: fromActor, ...entry });
    return true;
  });
}
