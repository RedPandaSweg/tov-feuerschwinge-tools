import { uiText } from "../core/localization.mjs";
import {
  createDefaultSessionRewards,
  createDefaultStationCategories,
  DEFAULT_MILESTONE_CATCH_UP,
  DEFAULT_MILESTONE_LEVEL_BANDS,
  DEFAULT_PASSIVE_DOWNTIME,
  DEFAULT_RECIPE_BASE_ITEM_UUID,
  FLAGS,
  MODULE_ID,
  SETTINGS
} from "./constants.mjs";
import { StationApp } from "./station-app.mjs?v=3.9.3-project-order-2";
import { StationConfigApp } from "./station-config-app.mjs?v=3.4.2-progress-item-controls-1";
import { ModuleItemSettingsApp } from "./module-item-settings-app.mjs";
import { PlayerActorFolderSettingsApp } from "./player-actor-folder-settings-app.mjs";
import { SessionRewardConfigApp } from "./session-reward-config-app.mjs";
import { HelpApp } from "./help-app.mjs";
import { ProjectLibraryApp } from "./project-library-app.mjs";
import { getSystemAdapter, registerSystemAdapter } from "./system-adapter.mjs";
import { SessionApp } from "./session-app.mjs?v=3.7.8-standard-effects-2";
import { openCampaign } from "../campaign/app.mjs";
import { registerCampaignService, isCampaignWorld } from "../campaign/service.mjs?v=3.7.8-permissions-1";
import { UserTransferApp } from "../transfer/user-transfer-app.mjs";
import { DowntimeItemApp } from "./downtime-item-app.mjs";
import { StationPresetApp } from "./station-preset-app.mjs";
import { playerCharacters, sessionProgress, SessionService } from "./session-service.mjs";
import { registerSharedProjectSocket } from "./shared-project-socket.mjs?v=3.8.5-applied-roll-progress-1";
import { downtimeItemData, DowntimeItemService } from "./downtime-item-service.mjs";
import { addHeaderControl, defaultStationData, isRecipeItem, isStation } from "./utils.mjs";
import {
  configureAsRecipe,
  createRecipeFromBaseItem,
  openRecipeEditor
} from "./recipe-service.mjs?v=3.4.2-project-collaborative-default-1";
import { MIGRATION_SETTING, migrateIntegratedDowntime } from "./migration.mjs";
import { openFeuerschwingeSettings } from "../settings-categories.mjs";
import { createWorldSpellScroll } from "../spell-scrolls.mjs?v=3.7.8-clearance-label-1";
import { GMToolsApp } from "./gm-tools-app.mjs?v=3.8.0-unresolved-advancement-formulas-1";
import { canSynchronizeCompendiumItem, synchronizeCompendiumItem } from "../item-compendium-sync.mjs?v=3.8.5-preferred-source-sync-1";
import { RaffleApp, configureRaffle } from "./raffle-app.mjs?v=3.8.5-raffle-packages-3";
import { isRaffle } from "./raffle-service.mjs?v=3.8.5-raffle-packages-2";
import { registerRaffleSocket } from "./raffle-socket.mjs?v=3.8.5-raffle-packages-2";
import { enableStationViewerAccess, reconcileStationViewerAccess } from "./station-access.mjs";

function documentFromApp(app, documentName) {
  const document =
    app?.item ??
    app?.document ??
    app?.object ??
    app?.actor;

  return document?.documentName === documentName
    ? document
    : null;
}

function openStation(actor) {
  if (!isStation(actor)) {
    return ui.notifications.warn(
      game.i18n.localize("DOWNTIME_MANAGER.Errors.NotStation")
    );
  }

  new StationApp(actor).render(true);
}

function openRaffle(actor) { if (isRaffle(actor)) new RaffleApp(actor).render(true); }

function openDashboard() {
  if (game.user.isGM) { const app = new GMToolsApp(); app.tab = "projects"; app.render(true); }
}

function openSessionManager() {
  if (!game.user.isGM) return;
  new SessionApp().render(true);
}

function openProjectLibrary() {
  if (game.user.isGM) new ProjectLibraryApp().render(true);
}

function openGMTools() {
  if (game.user.isGM) new GMToolsApp().render(true);
}

function openCompendiumLibrary() {
  game.modules.get(MODULE_ID)?.api?.openLibrary?.();
}

async function configureStation(actor, app = null) {
  if (game.user.isGM) {
    if (!isStation(actor)) {
      await actor.setFlag(MODULE_ID, FLAGS.STATION, defaultStationData());
      await enableStationViewerAccess(actor);
      app?.render?.();
    }
    new StationConfigApp(actor).render(true);
  }
}

function registerTokenDoubleClick() {
  const TokenClass = CONFIG.Token.objectClass;
  const prototype = TokenClass?.prototype;

  if (!prototype) {
    console.error(`${MODULE_ID} | Token class is unavailable.`);
    return;
  }

  if (prototype.__downtimeManagerDoubleClickPatched) return;

  const originalDoubleClick = prototype._onClickLeft2;
  const originalCanView = prototype._canView;

  if (typeof originalDoubleClick !== "function" || typeof originalCanView !== "function") {
    console.error(
      `${MODULE_ID} | Token interaction methods are unavailable.`
    );
    return;
  }

  Object.defineProperty(
    prototype,
    "__downtimeManagerDoubleClickPatched",
    {
      value: true,
      configurable: true
    }
  );

  // Foundry checks _canView before dispatching a token double-click. Station
  // Actors normally are not owned by players, so their double-click handler
  // would otherwise never run even though the station UI is player-facing.
  prototype._canView = function (user, event) {
    const isCommerce = this.actor?.getFlag?.(MODULE_ID, "merchant")?.enabled === true
      || this.actor?.getFlag?.(MODULE_ID, "auctionHouse")?.enabled === true;
    if (isStation(this.actor) || isCommerce || isRaffle(this.actor)) {
      if (!this.layer?.active) return false;
      if (canvas.regions?._placementContext) return false;
      if (this.layer._draggedToken) return false;
      if (canvas.controls?.ruler?.active) return false;
      if (CONFIG.Canvas.rulerClass.canMeasure && event?.type === "pointerdown") return false;
      return true;
    }

    return originalCanView.call(this, user, event);
  };

  prototype._onClickLeft2 = function (event) {
    const merchant = this.actor?.getFlag?.(MODULE_ID, "merchant")?.enabled === true;
    const auctionHouse = this.actor?.getFlag?.(MODULE_ID, "auctionHouse")?.enabled === true;
    if (merchant || auctionHouse) {
      event?.stopPropagation?.();
      void import("../commerce/app.mjs?v=3.8.5-merchant-interactor-avatar-1").then(({ openCommerce }) => openCommerce({
        mode: merchant ? "merchant" : "auction",
        merchantId: merchant ? this.actor.id : null,
        auctionHouseId: auctionHouse ? this.actor.id : null
      }));
      return;
    }
    if (isStation(this.actor)) {
      event?.stopPropagation?.();
      openStation(this.actor);
      return;
    }
    if (isRaffle(this.actor)) { event?.stopPropagation?.(); openRaffle(this.actor); return; }

    return originalDoubleClick.call(this, event);
  };

}

export function registerDowntime() {
  if (game.system.id !== "black-flag") return;
  registerTokenDoubleClick();
  registerCampaignService();
  game.settings.registerMenu(MODULE_ID, "userTransfer", {
    name: uiText("TOVF.Interface.ImportExportUsers_006bc8", "Benutzer importieren / exportieren"), label: uiText("TOVF.Interface.OpenUserTransfer_f4d32a", "Benutzertransfer öffnen"),
    hint: uiText("TOVF.Interface.TransferUserProfilesAndCharacterAssignmentsBetween_3265a3", "Benutzerprofile und Charakterzuordnungen zwischen Live-, Test- und Sessionwelt übertragen."),
    icon: "fa-solid fa-users", type: UserTransferApp, restricted: true
  });

  game.settings.register(MODULE_ID, SETTINGS.ACTIVE_SESSION, { scope: "world", config: false, type: Object, default: {} });
  game.settings.register(MODULE_ID, SETTINGS.SESSION_IMPORT_HISTORY, { scope: "world", config: false, type: Object, default: { schemaVersion: 1, entries: [] } });
  game.settings.register(MODULE_ID, SETTINGS.SESSION_TRANSFER_LOG, { scope: "world", config: false, type: Object, default: { schemaVersion: 1, entries: [] } });
  game.settings.register(MODULE_ID, SETTINGS.LAST_SESSION_RESULT, { scope: "world", config: false, type: Object, default: {} });
  game.settings.register(MODULE_ID, SETTINGS.SESSION_REWARDS, { scope: "world", config: false, type: Object, default: createDefaultSessionRewards(getSystemAdapter().getDefaultGoldItemUuid()) });
  game.settings.register(MODULE_ID, SETTINGS.SESSION_HISTORY_JOURNAL, { scope: "world", config: false, type: String, default: "" });
  game.settings.register(MODULE_ID, SETTINGS.SESSION_HISTORY, { scope: "world", config: false, type: Object, default: { schemaVersion: 1, entries: [] } });
  game.settings.register(MODULE_ID, SETTINGS.SESSION_HISTORY_ENABLED, {
    name: "DOWNTIME_MANAGER.Settings.SessionHistory.Name",
    hint: "DOWNTIME_MANAGER.Settings.SessionHistory.Hint",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });
  game.settings.register(MODULE_ID, SETTINGS.STATION_CATEGORIES, {
    name: "DOWNTIME_MANAGER.Settings.StationCategories.Name",
    hint: "DOWNTIME_MANAGER.Settings.StationCategories.Hint",
    scope: "world",
    config: false,
    type: Object,
    default: {
      entries: createDefaultStationCategories(getSystemAdapter().getCheckDefinitions().map(check => ({
        ...check,
        label: check.localized ? game.i18n.localize(check.label) : game.i18n.localize(check.label)
      })))
    }
  });
  game.settings.register(MODULE_ID, SETTINGS.PLAYER_ACTOR_FOLDERS, {
    name: "DOWNTIME_MANAGER.Settings.PlayerActorFolders.Name",
    hint: "DOWNTIME_MANAGER.Settings.PlayerActorFolders.Hint",
    scope: "world",
    config: false,
    type: Object,
    default: { folderId: "" }
  });
  game.settings.register(MODULE_ID, SETTINGS.SESSION_TRANSFER_SCENES, {
    scope: "world", config: false, type: Object,
    default: { scenes: [] }
  });
  game.settings.register(MODULE_ID, SETTINGS.PASSIVE_DOWNTIME, {
    scope: "world", config: false, type: Object,
    default: foundry.utils.deepClone(DEFAULT_PASSIVE_DOWNTIME)
  });
  game.settings.register(MODULE_ID, SETTINGS.MILESTONE_LEVEL_BANDS, {
    scope: "world", config: false, type: Object,
    default: { entries: foundry.utils.deepClone(DEFAULT_MILESTONE_LEVEL_BANDS) }
  });
  game.settings.register(MODULE_ID, SETTINGS.MILESTONE_CATCH_UP, {
    scope: "world", config: false, type: Object,
    default: foundry.utils.deepClone(DEFAULT_MILESTONE_CATCH_UP)
  });
  game.settings.register(MODULE_ID, SETTINGS.LAST_DIRECT_DOWNTIME_ALL, {
    scope: "world", config: false, type: Object, default: {}
  });
  game.settings.register(MODULE_ID, SETTINGS.GM_TOOL_UNDO, {
    scope: "world", config: false, type: Object, default: {}
  });
  game.settings.register(MODULE_ID, MIGRATION_SETTING, {
    scope: "world", config: false, type: Number, default: 0
  });

  game.settings.register(MODULE_ID, SETTINGS.RECIPE_BASE_ITEM_UUID, {
    name: "DOWNTIME_MANAGER.Settings.ProjectBaseItem.Name",
    hint: "DOWNTIME_MANAGER.Settings.ProjectBaseItem.Hint",
    scope: "world",
    config: false,
    type: String,
    default: DEFAULT_RECIPE_BASE_ITEM_UUID
  });

  game.settings.register(MODULE_ID, SETTINGS.DEFAULT_COST_ITEM_UUID, {
    name: "DOWNTIME_MANAGER.Settings.DefaultCostItem.Name",
    hint: "DOWNTIME_MANAGER.Settings.DefaultCostItem.Hint",
    scope: "world",
    config: false,
    type: String,
    default: getSystemAdapter().getDefaultGoldItemUuid()
  });

  game.settings.registerMenu(MODULE_ID, "itemDefaults", {
    name: "DOWNTIME_MANAGER.Settings.ModuleConfig.Name",
    label: "DOWNTIME_MANAGER.Settings.ModuleConfig.Label",
    hint: "DOWNTIME_MANAGER.Settings.ModuleConfig.Hint",
    icon: "fa-solid fa-box-open",
    type: ModuleItemSettingsApp,
    restricted: true
  });

  game.settings.registerMenu(MODULE_ID, "playerActorFolders", {
    name: "DOWNTIME_MANAGER.Settings.PlayerActorFolders.SettingName",
    label: "DOWNTIME_MANAGER.Settings.PlayerActorFolders.SettingLabel",
    hint: "DOWNTIME_MANAGER.Settings.PlayerActorFolders.SettingHint",
    icon: "fa-solid fa-folder-tree",
    type: PlayerActorFolderSettingsApp,
    restricted: true
  });

  game.settings.registerMenu(MODULE_ID, "sessionRewards", {
    name: "DOWNTIME_MANAGER.Session.ConfigTitle",
    label: "DOWNTIME_MANAGER.Session.ConfigureRewards",
    hint: "DOWNTIME_MANAGER.Session.ConfigHint",
    icon: "fa-solid fa-gift",
    type: SessionRewardConfigApp,
    restricted: true
  });

  void loadTemplates().catch(error => {
    console.error(`${MODULE_ID} | Loading downtime templates failed.`, error);
  });

}

export async function activateDowntime() {
  if (game.system.id !== "black-flag" || !game.user) return;
  registerRaffleSocket();
  void game.user.setFlag(MODULE_ID, FLAGS.LAST_LOGIN_AT, Date.now()).catch(error =>
    console.warn(`${MODULE_ID} | Could not record the current user's last login`, error));

  await migrateIntegratedDowntime();
  if (game.user.isGM && !game.settings.get(MODULE_ID, SETTINGS.RECIPE_BASE_ITEM_UUID)) {
    await game.settings.set(MODULE_ID, SETTINGS.RECIPE_BASE_ITEM_UUID, DEFAULT_RECIPE_BASE_ITEM_UUID);
  }
  const sessionRewards = game.settings.get(MODULE_ID, SETTINGS.SESSION_REWARDS);
  if (game.user.isGM && Number(sessionRewards?.schemaVersion ?? 0) < 2) {
    await game.settings.set(
      MODULE_ID,
      SETTINGS.SESSION_REWARDS,
      createDefaultSessionRewards(getSystemAdapter().getDefaultGoldItemUuid())
    );
  }
  registerSharedProjectSocket();
  const storedCategories = game.settings.get(MODULE_ID, SETTINGS.STATION_CATEGORIES);
  if (!Array.isArray(storedCategories?.entries) || storedCategories.entries.some(category => !category || typeof category !== "object")) {
    const checks = getSystemAdapter().getCheckDefinitions().map(check => ({
      ...check,
      label: check.localized ? check.label : game.i18n.localize(check.label)
    }));
    await game.settings.set(MODULE_ID, SETTINGS.STATION_CATEGORIES, { entries: createDefaultStationCategories(checks) });
  } else if (storedCategories.entries.some(category => String(category.id).startsWith("tool:"))
    || !storedCategories.entries.some(category => category.id === "spell-scribing")) {
    const checks = getSystemAdapter().getCheckDefinitions();
    const semantic = createDefaultStationCategories(checks);
    const preserved = storedCategories.entries.filter(category => !String(category.id).startsWith("tool:"));
    const ids = new Set(preserved.map(category => category.id));
    await game.settings.set(MODULE_ID, SETTINGS.STATION_CATEGORIES, {
      entries: [...preserved, ...semantic.filter(category => !ids.has(category.id))]
    });
  }
  if (game.user.isGM) {
    for (const actor of game.actors.filter(entry => entry.getFlag?.(MODULE_ID, "preset")?.stationId === "scriptorium")) {
      const station = actor.getFlag(MODULE_ID, FLAGS.STATION);
      const preset = actor.getFlag(MODULE_ID, "preset");
      if (!station?.spellScrollRecipes || Number(preset?.version ?? 0) >= 2) continue;
      await actor.update({
        [`flags.${MODULE_ID}.${FLAGS.STATION}`]: {
          ...station,
          categories: ["spell-scribing"],
          baseProgress: 50,
          requiresRoll: false,
          rollInterval: 1,
          progressSources: {
            level: { enabled: false, multiplier: 1 },
            proficiency: { enabled: false, multiplier: 1 },
            checkProficiency: { enabled: false, multiplier: 1 }
          },
          allowedChecks: [],
          progressItems: [],
          modifiers: [],
          rollTable: [],
          rollTablePreset: "",
          actorValue: { ...(station.actorValue ?? {}), enabled: false, completionChange: 0 }
        },
        [`flags.${MODULE_ID}.preset.version`]: 2
      });
    }
    void reconcileStationViewerAccess();
  }
  getSystemAdapter().registerHooks({
    redeemDowntimeItem: (item, options) => DowntimeItemService.redeem(item, options)
  });
  const api = {
    openStation,
    configureStation,
    openRecipeEditor,
    configureAsRecipe,
    createRecipeFromBaseItem,
    openDashboard,
    openSessionManager,
    openCampaign,
    openUserTransfer: () => new UserTransferApp().render({ force: true }),
    openProjectLibrary,
    openGMTools,
    openStationPresets: () => game.user.isGM && new StationPresetApp().render(true),
    getSystemAdapter,
    registerSystemAdapter,
    getPlayerCharacters: () => playerCharacters(),
    getCharacterProgress: actor => foundry.utils.deepClone(sessionProgress(actor)),
    getActiveSession: () => foundry.utils.deepClone(game.settings.get(MODULE_ID, SETTINGS.ACTIVE_SESSION) ?? {}),
    getLastSessionResult: () => foundry.utils.deepClone(game.settings.get(MODULE_ID, SETTINGS.LAST_SESSION_RESULT) ?? {}),
    getSessionHistory: () => foundry.utils.deepClone(game.settings.get(MODULE_ID, SETTINGS.SESSION_HISTORY) ?? { schemaVersion: 1, entries: [] }),
    importSessionResult: result => game.settings.set(MODULE_ID, SETTINGS.LAST_SESSION_RESULT, foundry.utils.deepClone(result ?? {})),
    SessionService
  };
  game.feuerschwinge = api;
  game.downtimeManager = api;
  const module = game.modules.get(MODULE_ID);
  if (module) Object.assign(module.api ??= {}, api);
}

async function loadTemplates() {
  return foundry.applications.handlebars.loadTemplates([
    "modules/tov-feuerschwinge-tools/templates/downtime/partials/item-list.hbs",
    "modules/tov-feuerschwinge-tools/templates/downtime/partials/category-picker.hbs",
  ]);
}

function actorHeaderControls(app, controls) {
  if (!game.user.isGM) return;

  const actor = documentFromApp(app, "Actor");
  if (!actor) return;

  addHeaderControl(controls, {
    action: "tov-feuerschwinge-actor-actions",
    icon: "fa-solid fa-fire-flame-curved",
    label: game.i18n.localize("DOWNTIME_MANAGER.Headers.Feuerschwinge"),
    visible: true,
    onClick: async () => {
      const merchant = actor.getFlag(MODULE_ID, "merchant")?.enabled === true;
      const auctionHouse = actor.getFlag(MODULE_ID, "auctionHouse")?.enabled === true;
      const action = await foundry.applications.api.DialogV2.wait({
        classes: ["tovf-actor-actions-dialog"],
        window: { title: game.i18n.localize("DOWNTIME_MANAGER.Headers.Feuerschwinge") },
        position: { width: 560 },
        buttons: [
          { action: "merchant", icon: "fa-solid fa-shop", label: merchant ? uiText("TOVF.Interface.OpenAndManageMerchant_3334c1", "Händler öffnen und verwalten") : uiText("TOVF.Interface.ConfigureAsMerchant_7e184b", "Als Händler einrichten"), callback: () => "merchant" },
          { action: "auction", icon: "fa-solid fa-gavel", label: auctionHouse ? uiText("TOVF.Interface.OpenAuctionHouse_9a5133", "Auktionshaus öffnen") : "Als Auktionshaus einrichten", callback: () => "auction" },
          { action: "station", icon: "fa-solid fa-hammer", label: isStation(actor)
            ? game.i18n.localize("DOWNTIME_MANAGER.Headers.ConfigureStation")
            : game.i18n.localize("DOWNTIME_MANAGER.Headers.MakeStation"), callback: () => "station" },
          ...(isStation(actor) ? [{ action: "openStation", icon: "fa-solid fa-screwdriver-wrench", label: game.i18n.localize("DOWNTIME_MANAGER.Headers.OpenStation"), callback: () => "openStation" }] : [])
          , { action: "raffle", icon: "fa-solid fa-ticket", label: isRaffle(actor) ? "Raffle öffnen und verwalten" : "Als Raffle-NPC einrichten", callback: () => "raffle" }
        ],
        rejectClose: false
      });
      if (action === "station") return configureStation(actor, app);
      if (action === "openStation") return openStation(actor);
      if (action === "raffle") return isRaffle(actor) ? openRaffle(actor) : configureRaffle(actor);
      const commerce = await import("../commerce/app.mjs?v=3.8.5-merchant-interactor-avatar-1");
      if (action === "merchant") return merchant ? commerce.openCommerce({ mode: "merchant", merchantId: actor.id, shopPage: "management" }) : commerce.configureMerchantActor(actor, app);
      if (action === "auction") return auctionHouse ? commerce.openCommerce({ mode: "auction", auctionHouseId: actor.id }) : commerce.configureAuctionHouseActor(actor, app);
    }
  });
}

function itemHeaderControls(app, controls) {
  const item = documentFromApp(app, "Item");
  if (!item || !game.user.isGM) return;
  const isDowntimeItem = Boolean(downtimeItemData(item));

  addHeaderControl(controls, {
    action: "tov-feuerschwinge-item-actions",
    icon: "fa-solid fa-fire-flame-curved",
    label: game.i18n.localize("DOWNTIME_MANAGER.Headers.Feuerschwinge"),
    visible: true,
    onClick: async () => {
      try {
        const buttons = [{
          action: "downtime",
          icon: isRecipeItem(item) ? "fa-solid fa-scroll" : "fa-solid fa-hourglass-half",
          label: game.i18n.localize(
            isRecipeItem(item)
              ? "DOWNTIME_MANAGER.Headers.ConfigureProject"
              : isDowntimeItem
                ? "DOWNTIME_MANAGER.DowntimeItem.Configure"
                : "DOWNTIME_MANAGER.DowntimeItem.ConfigureGeneric"
          ),
          callback: () => "downtime"
        }];

        if (canSynchronizeCompendiumItem(item)) {
          buttons.push({
            action: "synchronize",
            icon: "fa-solid fa-arrows-rotate",
            label: game.i18n.localize("DOWNTIME_MANAGER.ItemSync.Action"),
            callback: () => "synchronize"
          });
        }

        if (item.type === "spell") {
          buttons.push({
            action: "spellScroll",
            icon: "fa-solid fa-scroll",
            label: "Spellscroll erstellen",
            callback: () => "spellScroll"
          });
        }

        const action = await foundry.applications.api.DialogV2.wait({
          classes: ["tovf-actor-actions-dialog"],
          window: {
            title: game.i18n.localize("DOWNTIME_MANAGER.Headers.Feuerschwinge")
          },
          position: { width: 510 },
          buttons,
          rejectClose: false
        });

        if (action === "synchronize") {
          await synchronizeCompendiumItem(item);
        } else if (action === "spellScroll") {
          const scroll = await createWorldSpellScroll(item, { folder: item.pack || item.parent ? null : item.folder });
          if (scroll) ui.notifications.info(`${scroll.name} wurde im Item-Verzeichnis erstellt.`);
        } else if (action === "downtime") {
          if (isRecipeItem(item)) openRecipeEditor(item);
          else new DowntimeItemApp(item).render(true);
        }
      } catch (error) {
        console.error(error);
        ui.notifications.error(error.message);
      }
    }
  });
}

Hooks.on("getHeaderControlsActorSheetV2", actorHeaderControls);
Hooks.on("getHeaderControlsItemSheetV2", itemHeaderControls);

Hooks.on("getHeaderControlsApplicationV2", (app, controls) => {
  actorHeaderControls(app, controls);
  itemHeaderControls(app, controls);
});

Hooks.on("getSceneControlButtons", controls => {
  if (game.system.id !== "black-flag") return;
  if (!game.user.isGM) return;

  controls.feuerschwinge = {
    name: "feuerschwinge",
    order: 999,
    title: "DOWNTIME_MANAGER.Controls.Title",
    icon: "fa-solid fa-fire-flame-curved",
    tools: {
      session: {
        name: "session",
        order: 1,
        title: "DOWNTIME_MANAGER.Controls.OpenSessionManager",
        icon: "fa-solid fa-scroll",
        button: true,
        onChange: openSessionManager
      },
      challenge: {
        name: "challenge",
        order: 2,
        title: "TOVF.ChallengeManager.Open",
        icon: "fa-solid fa-skull-crossbones",
        button: true,
        onChange: () => game.modules.get(MODULE_ID)?.api?.toggleChallengeManager?.()
      },
      gmTools: {
        name: "gmTools",
        order: 4,
        title: "DOWNTIME_MANAGER.GMTools.Open",
        icon: "fa-solid fa-screwdriver-wrench",
        button: true,
        onChange: openGMTools
      },
      library: {
        name: "library",
        order: 5,
        title: "TOVF.Library.Open",
        icon: "fa-solid fa-books",
        button: true,
        onChange: openCompendiumLibrary
      },
      ...(isCampaignWorld() ? { campaign: { name: "campaign", order: 6, title: "Belohnungsverwaltung", icon: "fa-solid fa-gift", button: true, onChange: openCampaign } } : {}),
      settings: {
        name: "settings",
        order: 7,
        title: "TOVF.Controls.OpenSettings",
        icon: "fa-solid fa-gear",
        button: true,
        onChange: openFeuerschwingeSettings
      },
      help: {
        name: "help",
        order: 8,
        title: "TOVF.Help.Label",
        icon: "fa-solid fa-circle-question",
        button: true,
        onChange: () => new HelpApp().render(true)
      }
    },
    activeTool: null
  };
});
