import {
  DEFAULT_PROJECT_CONFIG,
  DEFAULT_STATION_CONFIG,
  FLAGS,
  MODULE_ID,
  SETTINGS
} from "./constants.mjs";
import { getSystemAdapter } from "./system-adapter.mjs";
import { spellScrollLevel } from "../spell-scrolls.mjs?v=3.8.5-scroll-activation-1";

export function itemIdentifier(item) {
  return String(item?.system?.identifier?.value ?? item?.system?.identifier ?? item?.system?.slug ?? item?.getFlag?.(MODULE_ID, "resourceIdentifier") ?? item?.name ?? "").trim().toLowerCase();
}
export function sourceUuid(item) {
  return item?._stats?.compendiumSource
    ?? item?._stats?.duplicateSource
    ?? item?.uuid
    ?? "";
}
export function getQuantity(item) { return getSystemAdapter().getQuantity(item); }
export function quantityUpdate(item, quantity) { return getSystemAdapter().quantityUpdate(item, quantity); }
export function toolMatches(item, requiredTool) {
  if (!requiredTool?.uuid && !requiredTool?.identifier && !requiredTool?.name) return false;
  const itemName = String(item.name ?? "").trim().toLocaleLowerCase();
  const storedName = String(requiredTool.name ?? "").trim().toLocaleLowerCase();
  const configuredName = requiredTool.identifier
    ? (globalThis.CONFIG?.BlackFlag?.tools?.localizedOptions ?? []).find(option => option.value === requiredTool.identifier)?.label
    : "";
  return Boolean(
    (requiredTool.uuid && String(sourceUuid(item)).toLowerCase() === String(requiredTool.uuid).toLowerCase()) ||
    (requiredTool.identifier && itemIdentifier(item) === String(requiredTool.identifier).toLowerCase()) ||
    (storedName && itemName === storedName) ||
    (configuredName && itemName === String(configuredName).trim().toLocaleLowerCase())
  );
}
export function hasRequiredTool(actor, requiredTool) {
  const status = toolRequirementStatus(actor, requiredTool);
  return !status.required || (status.present && status.proficient);
}
export function toolRequirementStatus(actor, requiredTool) {
  const required = Boolean(requiredTool?.uuid || requiredTool?.identifier || requiredTool?.name);
  if (!required) return { required: false, present: true, proficient: true, name: "" };
  const matching = actor.items.filter(item => toolMatches(item, requiredTool));
  const configuredName = requiredTool.identifier
    ? (globalThis.CONFIG?.BlackFlag?.tools?.localizedOptions ?? []).find(option => option.value === requiredTool.identifier)?.label
    : "";
  const identifier = String(requiredTool.identifier ?? "").trim().toLowerCase();
  // Item identifiers (e.g. "trapper-tools") need not be proficiency keys
  // ("trapper"). An absent key must not override the owned item's result.
  const toolProficiency = identifier ? actor.system?.proficiencies?.tools?.[identifier] : null;
  const actorProficiency = toolProficiency != null
    ? Number(toolProficiency.proficiency?.multiplier ?? 0) > 0
    : null;
  return {
    required: true,
    present: matching.length > 0,
    proficient: actorProficiency ?? matching.some(item => getSystemAdapter().isItemProficient(item)),
    name: String(requiredTool.name || configuredName || requiredTool.identifier || "").trim()
  };
}
export function actorKnowsSpell(actor, spell, { origin = "" } = {}) {
  if (!actor || spell?.type !== "spell") return false;
  const targetIdentifier = itemIdentifier(spell);
  const targetSource = String(sourceUuid(spell)).toLowerCase();
  const targetName = String(spell.name ?? "").trim().toLocaleLowerCase();
  const targetCircle = Number(spell.system?.circle?.value ?? spell.system?.circle?.base ?? spell.system?.circle ?? spell.system?.level ?? 0);
  return actor.items.some(item => {
    if (item.type !== "spell") return false;
    if (origin && String(item.getFlag?.(game.system.id, "relationship.origin.identifier") ?? "").trim().toLowerCase() !== origin) return false;
    if (targetIdentifier && itemIdentifier(item) === targetIdentifier) return true;
    if (targetSource && String(sourceUuid(item)).toLowerCase() === targetSource) return true;
    const name = String(item.name ?? "").trim().toLocaleLowerCase();
    const circle = Number(item.system?.circle?.value ?? item.system?.circle?.base ?? item.system?.circle ?? item.system?.level ?? 0);
    return Boolean(targetName && name === targetName && circle === targetCircle);
  });
}
export function isRecipeItem(item) { return Boolean(item?.getFlag?.(MODULE_ID, FLAGS.RECIPE)?.enabled); }

export function parseCategories(value) {
  const entries = Array.isArray(value) ? value : String(value ?? "").split(",");
  const categories = [];
  const keys = new Set();
  for (const entry of entries) {
    const category = String(entry ?? "").trim();
    const key = category.toLocaleLowerCase();
    if (!category || keys.has(key)) continue;
    keys.add(key);
    categories.push(category);
  }
  return categories;
}
export function configuredCategories() {
  const stored = game.settings.get(MODULE_ID, SETTINGS.STATION_CATEGORIES);
  const entries = Array.isArray(stored?.entries)
    ? stored.entries
    : Array.isArray(stored)
      ? stored
    : parseCategories(stored).map(value => ({ id: value, label: value }));
  const result = [];
  const ids = new Set();
  for (const entry of entries) {
    const id = String(entry?.id ?? entry ?? "").trim().toLowerCase();
    const label = String(entry?.label ?? entry?.id ?? entry ?? "").trim();
    if (!id || !label || ids.has(id)) continue;
    ids.add(id);
    result.push({ id, label });
  }
  return result;
}
export function categorySelectionView(selected = []) {
  const categories = configuredCategories();
  const selectedIds = new Set(parseCategories(selected).map(id => id.toLocaleLowerCase()));
  return {
    selected: categories.filter(category => selectedIds.has(category.id)),
    options: categories.filter(category => !selectedIds.has(category.id))
  };
}
export function addCategorySelection(element) {
  const picker = element.closest(".sc-category-picker");
  const select = picker?.querySelector("[data-category-select]");
  const option = select?.selectedOptions?.[0];
  if (!option?.value || picker.querySelector(`[data-category-id="${CSS.escape(option.value)}"]`)) return;
  const chip = document.createElement("span");
  chip.className = "sc-category-chip";
  chip.dataset.categoryId = option.value;
  const input = document.createElement("input");
  input.type = "hidden";
  input.name = "categories";
  input.value = option.value;
  const label = document.createElement("span");
  label.textContent = option.textContent;
  const button = document.createElement("button");
  button.type = "button";
  button.dataset.action = "removeCategorySelection";
  button.title = game.i18n.localize("DOWNTIME_MANAGER.Actions.Remove");
  button.innerHTML = '<i class="fa-solid fa-xmark"></i>';
  chip.append(input, label, button);
  picker.querySelector("[data-category-chips]")?.append(chip);
  const valueCategory = picker.closest("form")?.querySelector('[name="actorValue.category"]');
  if (valueCategory && !Array.from(valueCategory.options).some(entry => entry.value === option.value)) {
    valueCategory.add(new Option(option.textContent, option.value));
  }
  option.remove();
  select.value = "";
}
export function removeCategorySelection(element) {
  const chip = element.closest(".sc-category-chip");
  const picker = chip?.closest(".sc-category-picker");
  const select = picker?.querySelector("[data-category-select]");
  if (!chip || !select) return;
  const option = document.createElement("option");
  option.value = chip.dataset.categoryId;
  option.textContent = chip.querySelector(":scope > span")?.textContent ?? option.value;
  select.append(option);
  const valueCategory = picker.closest("form")?.querySelector('[name="actorValue.category"]');
  valueCategory?.querySelector(`option[value="${CSS.escape(option.value)}"]`)?.remove();
  chip.remove();
}

export function categoriesMatch(stationCategories, projectCategories) {
  const available = new Set(parseCategories(stationCategories).map(category => category.toLocaleLowerCase()));
  return parseCategories(projectCategories)
    .some(category => available.has(category.toLocaleLowerCase()));
}
export function getItemPriceGp(item) {
  return round(getSystemAdapter().getItemPrice(item), 4);
}
export function getActiveCrafter() { return canvas?.tokens?.controlled?.find(t => t.actor)?.actor ?? game.user.character ?? null; }
export function round(value, places = 4) { const f = 10 ** places; return Math.round((Number(value) + Number.EPSILON) * f) / f; }
export function addHeaderControl(controls, control) { if (!Array.isArray(controls) || controls.some(e => e.action === control.action)) return; controls.unshift(control); }

export function getStationData(actor) {
  const stored = foundry.utils.deepClone(
    actor.getFlag(MODULE_ID, FLAGS.STATION) ?? {}
  );
  const data = foundry.utils.mergeObject(
    defaultStationData(),
    stored,
    { inplace: false, recursive: true }
  );
  data.categories = parseCategories(data.categories);

  // Read existing station data without persisting a migration.
  const existingChecks = stored.working?.allowedChecks?.length
    ? stored.working.allowedChecks
    : DEFAULT_STATION_CONFIG.allowedChecks;
  data.allowedChecks = normalizeChecks(
    Object.hasOwn(stored, "allowedChecks") ? stored.allowedChecks : existingChecks
  );
  data.recipes = Array.isArray(stored.recipes) ? stored.recipes : [];
  data.progressItems = (Array.isArray(stored.progressItems) ? stored.progressItems : [])
    .filter(entry => entry?.uuid)
    .map(entry => ({
      uuid: String(entry.uuid),
      name: String(entry.name ?? ""),
      img: String(entry.img ?? ""),
      identifier: String(entry.identifier ?? ""),
      progress: Math.max(0.000001, Number(entry.progress) || 1)
    }));
  data.modifiers = Array.isArray(stored.modifiers) ? stored.modifiers : [];
  data.progressSources = foundry.utils.mergeObject(
    foundry.utils.deepClone(DEFAULT_STATION_CONFIG.progressSources),
    stored.progressSources ?? {},
    { inplace: false, recursive: true }
  );
  const adapter = getSystemAdapter();
  if (!adapter.capabilities.checks) {
    data.allowedChecks = [];
    data.requiresRoll = false;
    data.progressSources.checkProficiency.enabled = false;
  }
  if (!adapter.capabilities.actorSources) {
    data.progressSources.level.enabled = false;
    data.progressSources.proficiency.enabled = false;
  }
  const storedRollTable = Array.isArray(stored.rollTable) ? stored.rollTable : [];
  const natural1 = storedRollTable.find(row => row.natural1);
  const natural20 = storedRollTable.find(row => row.natural20);
  const normalRows = storedRollTable.filter(row => !row.natural1 && !row.natural20);
  data.rollTable = [
    ...(natural1 ? [{ ...natural1, enabled: natural1.enabled !== false, natural1: true, natural20: false }] : []),
    ...normalRows.map(row => ({ ...row, enabled: true, natural1: false, natural20: false })),
    ...(natural20 ? [{ ...natural20, enabled: natural20.enabled !== false, natural1: false, natural20: true }] : [])
  ];
  data.actorValue = foundry.utils.mergeObject(
    foundry.utils.deepClone(DEFAULT_STATION_CONFIG.actorValue),
    stored.actorValue ?? {},
    { inplace: false, recursive: true }
  );
  return data;
}
export function isStation(actor) { return Boolean(actor?.getFlag?.(MODULE_ID, FLAGS.STATION)); }

export function defaultRecipeData() {
  return foundry.utils.mergeObject(
    foundry.utils.deepClone(DEFAULT_PROJECT_CONFIG),
    {
    itemPrice: 0,
    resultUuid: "",
    resultQuantity: 1,
    ingredients: []
    },
    { inplace: false }
  );
}

function spellRecipeCosts(item) {
  if (item?.type !== "spell") return null;
  const rawCircle = item.system?.circle?.value
    ?? item.system?.circle?.base
    ?? item.system?.circle
    ?? item.system?.level
    ?? 0;
  const circle = Math.max(0, Math.floor(Number(rawCircle) || 0));
  const goldCost = circle === 0 ? 10 : circle * 50;
  return { circle, goldCost, requiredProgress: goldCost * 2 };
}

export function spellScrollReference(item) {
  const data = item?.getFlag?.(MODULE_ID, "spellScroll");
  const spellUuid = String(data?.spellUuid ?? "").trim();
  const circle = Number(data?.circle);
  if (item?.type !== "consumable" || !spellUuid || !Number.isInteger(circle)) return null;
  return { ...data, spellUuid, circle };
}

export async function spellScrollRecipeData(item) {
  const reference = spellScrollReference(item);
  if (!reference) return null;
  const spell = await fromUuid(reference.spellUuid).catch(() => null);
  if (spell?.documentName !== "Item" || spell.type !== "spell") return null;
  const definition = recipeData(spell, { sourceUuid: spell.uuid });
  return {
    spell,
    definition: {
      ...definition,
      isCustom: true,
      spellScroll: true,
      scrollUuid: item.uuid,
      resultUuid: spell.uuid,
      description: game.i18n.format("DOWNTIME_MANAGER.Project.SpellScrollTransferDescription", {
        spell: spell.name,
        circle: reference.circle
      }),
      repeatable: false,
      collaborative: false,
      ingredients: [],
      completionCosts: [],
      rewards: [{ uuid: spell.uuid, quantity: 1, spellbookOrigin: "wizard" }]
    }
  };
}

export function spellScrollScribingRecipeData(spell) {
  if (spell?.documentName !== "Item" || spell.type !== "spell" || !spell.parent) return null;
  const level = spellScrollLevel(spell);
  if (!level) return null;
  const definition = recipeData(spell, { sourceUuid: spell.uuid });
  return {
    spell,
    definition: {
      ...definition,
      isCustom: true,
      spellScrollScribing: true,
      projectName: game.i18n.format("DOWNTIME_MANAGER.Project.SpellScrollScribingName", { spell: spell.name }),
      description: game.i18n.format("DOWNTIME_MANAGER.Project.SpellScrollScribingDescription", { spell: spell.name }),
      resultUuid: spell.uuid,
      itemPrice: level.price,
      progressCost: level.price,
      requiredProgress: level.price,
      goldCost: round(level.price * 0.5, 4),
      repeatable: true,
      collaborative: false,
      ingredients: [],
      completionCosts: [],
      rewards: [{ uuid: spell.uuid, quantity: 1, spellScroll: true }]
    }
  };
}

export function recipeData(item, { sourceUuid: explicitUuid = "" } = {}) {
  if (isRecipeItem(item)) {
    const stored = foundry.utils.deepClone(
      item.getFlag(MODULE_ID, FLAGS.RECIPE) ?? {}
    );
    const data = foundry.utils.mergeObject(
      defaultRecipeData(),
      stored,
      { inplace: false }
    );

    const itemPrice = 0;

    const existingResultReward = data.resultUuid
      ? [{ uuid: data.resultUuid, quantity: Number(data.resultQuantity) || 1 }]
      : [];
    return {
      ...data,
      categories: parseCategories(data.categories),
      enabled: data.enabled !== false,
      isCustom: true,
      itemPrice,
      goldCost: round(itemPrice * 0.5, 4),
      progressCost: round(itemPrice, 4),
      resultUuid: data.resultUuid ?? "",
      resultQuantity: Number(data.resultQuantity) || 1,
      ingredients: Array.isArray(data.ingredients)
        ? data.ingredients
        : [],
      requiredProgress: Math.max(
        0.0001,
        Number(Object.hasOwn(stored, "requiredProgress")
          ? stored.requiredProgress
          : itemPrice) || 0.0001
      ),
      rewards: Array.isArray(data.rewards) && data.rewards.length
        ? data.rewards
        : existingResultReward,
      completionCosts: Array.isArray(data.completionCosts) ? data.completionCosts : [],
      allowedChecks: normalizeChecks(data.allowedChecks),
      rollTable: Array.isArray(data.rollTable)
        ? data.rollTable.map(row => ({
          ...row,
          enabled: row.natural1 || row.natural20 ? row.enabled !== false : true,
          natural1: Boolean(row.natural1),
          natural20: Boolean(row.natural20)
        }))
        : [],
      requiredTools: Array.isArray(data.requiredTools) ? data.requiredTools : []
    };
  }

  const uuid = explicitUuid || sourceUuid(item);
  const spellCosts = spellRecipeCosts(item);
  const price = spellCosts?.requiredProgress ?? getItemPriceGp(item);

  return {
    enabled: true,
    isCustom: false,
    resultUuid: uuid,
    resultQuantity: 1,
    itemPrice: price,
    progressCost: price,
    requiredProgress: Math.max(0.0001, price),
    goldCost: spellCosts?.goldCost ?? round(price * 0.5, 4),
    spellCircle: spellCosts?.circle ?? null,
    ingredients: [],
    description: item?.system?.description?.value ?? "",
    categories: [],
    repeatable: true,
    allowedChecks: [],
    requiredTools: [],
    completionCosts: [],
    rewards: uuid ? [{ uuid, quantity: 1 }] : [],
    rollTable: [],
    conditions: []
  };
}

export function defaultStationData() {
  const data = foundry.utils.deepClone(DEFAULT_STATION_CONFIG);
  const adapter = getSystemAdapter();
  if (!adapter.capabilities.checks) data.requiresRoll = false;
  return data;
}

export function normalizeChecks(checks = []) {
  return (Array.isArray(checks) ? checks : [])
    .map(check => {
      if (typeof check === "string") {
        const [type, key] = check.split(":");
        return { type, key };
      }
      return { type: check?.type, key: check?.key };
    })
    .filter(check => check.type && check.key);
}
