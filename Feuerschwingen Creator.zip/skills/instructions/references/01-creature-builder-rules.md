# Creature Builder Knowledge Rules

The GPT produces compact design data, not Foundry Actor documents. The
Feuerschwinge module validates the Creature JSON, resolves locally installed spells,
constructs Black Flag Items and Activities, and creates the Actor.

Always use:

- `format`: `tov-feuerschwinge.creature`
- `version`: `1`
- English field names, enum values, and mechanical terms
- numeric distances in feet
- concise but mechanically complete descriptions

The required root fields are `format`, `version`, `name`, `cr`, `role`, `size`,
`creatureType`, `description`, `stats`, `abilities`, `movement`, `traits`,
`actions`, and `spellcasting`.

`stats` contains only `ac`, `hp`, `attackBonus`, and `saveDC`.

`abilities` contains exactly `str`, `dex`, `con`, `int`, `wis`, and `cha`.

Put every attack, save ability, special action, passive trait, Bonus Action,
and Reaction in the single root-level `actions` array. Never output the
obsolete fields `attacks`, `saveActions`, `features`, `bonusActions`, or
`reactions`. Never put creature mechanics inside `abilities`.

Valid action kinds are `attack`, `save`, `utility`, and `passive`. Valid
activations are `action`, `bonus`, `reaction`, and `passive`.

Use damage arrays even when an action has only one damage part:

```json
"damage": [{"formula": "2d8+4", "type": "force"}]
```

For Recharge 5–6 use:

```json
"uses": {"type": "recharge", "value": 5}
```

For three uses per day use:

```json
"uses": {"type": "limited", "value": 3, "recovery": "day"}
```

Put uncommon mechanics in `description` instead of inventing fields.

Spellcasters select exact official spell names from
`04-approved-spell-index.json`. Put them in `spellcasting.spells`; do not
reproduce official spell descriptions or Foundry Item data. If no indexed
spell fits an essential effect, define a new original spell under
`spellcasting.customSpells` using the schema. Use `spellcasting: null` for
creatures without spells.

Never invoke a tool. Never include Foundry `_id`, UUID, Compendium references,
Activities, complete Spell Items, image instructions, executable code, or
download claims. The words create, build, design, generate, make, erstellen,
erschaffen, bauen, and entwerfen always mean writing Creature JSON text, never
creating an image.

The brief must be complete without follow-up. Choose sensible defaults when
the user omits details.
