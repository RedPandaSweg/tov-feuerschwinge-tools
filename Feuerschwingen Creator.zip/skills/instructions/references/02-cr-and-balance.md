# CR and Balance Procedure

CR estimates total combat threat, not HP alone. Use these 5E-compatible values
as a heuristic rather than an immutable rule. AC is a soft benchmark, not a
hard lock: a creature with AC 2 points above or below the listed target is
usually still in the right band for that CR if the rest of its profile fits.
Treat the table as a starting point for a defensive profile, not a strict
formula.

| CR | PB | Typical AC | Target HP | Attack Bonus | Save DC | DPR |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 2 | 13 | 1–6 | 3 | 13 | 0–1 |
| 1/8 | 2 | 13 | 7–13 | 3 | 13 | 2–3 |
| 1/4 | 2 | 13 | 13–19 | 3 | 13 | 4–5 |
| 1/2 | 2 | 13 | 20–26 | 3 | 13 | 6–8 |
| 1 | 2 | 13 | 27–37 | 3 | 13 | 9–14 |
| 2 | 2 | 13 | 38–52 | 3 | 13 | 15–20 |
| 3 | 2 | 13 | 53–67 | 4 | 13 | 21–26 |
| 4 | 2 | 14 | 68–82 | 5 | 14 | 27–32 |
| 5 | 3 | 15 | 83–97 | 6 | 15 | 33–38 |
| 6 | 3 | 15 | 98–112 | 6 | 15 | 39–44 |
| 7 | 3 | 15 | 113–127 | 6 | 15 | 45–50 |
| 8 | 3 | 16 | 128–142 | 7 | 16 | 51–56 |
| 9 | 4 | 16 | 143–157 | 7 | 16 | 57–62 |
| 10 | 4 | 17 | 158–172 | 7 | 16 | 63–68 |
| 11 | 4 | 17 | 173–187 | 8 | 17 | 69–74 |
| 12 | 4 | 17 | 188–202 | 8 | 17 | 75–80 |
| 13 | 5 | 18 | 203–217 | 8 | 18 | 81–86 |
| 14 | 5 | 18 | 218–232 | 8 | 18 | 87–92 |
| 15 | 5 | 18 | 233–247 | 8 | 18 | 93–98 |
| 16 | 5 | 18 | 248–262 | 9 | 18 | 99–104 |
| 17 | 6 | 19 | 263–277 | 10 | 19 | 105–110 |
| 18 | 6 | 19 | 278–292 | 10 | 19 | 111–116 |
| 19 | 6 | 19 | 293–307 | 10 | 19 | 117–122 |
| 20 | 6 | 19 | 308–322 | 10 | 19 | 123–140 |
| 21 | 7 | 19 | 323–337 | 11 | 20 | 141–158 |
| 22 | 7 | 19 | 338–352 | 11 | 20 | 159–176 |
| 23 | 7 | 19 | 353–367 | 11 | 20 | 177–194 |
| 24 | 7 | 19 | 368–382 | 11 | 21 | 195–212 |
| 25 | 8 | 19 | 383–397 | 12 | 21 | 213–230 |
| 26 | 8 | 19 | 398–412 | 12 | 22 | 231–248 |
| 27 | 8 | 19 | 413–427 | 12 | 22 | 249–266 |
| 28 | 8 | 19 | 428–442 | 12 | 22 | 267–284 |
| 29 | 9 | 19 | 443–457 | 14 | 22 | 285–302 |
| 30 | 9 | 19 | 458–472 | 14 | 23 | 303–320 |

Extrapolate above CR 20 and test especially carefully.

## Defensive CR

1. Determine effective HP and map it to a CR row.
2. Compare actual AC to the row's Typical AC band.
3. Use AC as a nudge rather than a law: a moderate deviation can be offset by
   durability, mobility, resistance, control, or other defensive strengths.

A monster can sit comfortably within a CR even with AC 2 points lower or higher
than the target if its offense, control, or durability compensate. AC that is
3-4 points outside the target should trigger closer inspection, especially if
HP, save profile, or mobility are also unusually strong or weak.

Effective HP can increase through broadly relevant resistance or immunity,
regeneration, healing, temporary HP, frequent attack disadvantage, difficult
flight or range, Legendary Resistance, and protection from control chains.
Account for expected character level, counterplay, and affected rounds; never
apply a blanket multiplier without justification.

## Offensive CR

1. Simulate the strongest realistic three-round sequence.
2. Add expected damage and divide by three.
3. Assume an area effect hits two targets unless context supports another count.
4. Weight recharge actions by realistic availability.
5. Map DPR to a CR row.
6. Shift the estimate about one CR for each 2-point Attack Bonus or Save DC
   difference.

Count every attack in Multiattack. Include reaction damage when its trigger is
likely. Count ongoing damage only for realistically expected rounds. For
spellcasters, include their actual embedded spell selection rather than an
imaginary generic spell list.

## Control and action economy

Strong conditions, repeatable area control, isolation, summons, dominant forced
movement, and full actions outside the creature's turn can raise offensive CR
or require lower DPR. A single failed save that removes a character for several
rounds is a major warning sign.

## Final CR

Average the offensive and defensive estimates, then apply design judgment.
Treat the table as a guide to the expected range, not a strict arithmetic
formula. If the monster's AC, HP, or damage profile is materially outside the
row's band, explain why the actual play pattern still fits the intended CR.

Check whether the monster can immediately defeat an appropriate character,
whether one condition can neutralize it, whether an ability scales excessively
with target count, whether hidden burst damage exists, and whether the monster
remains interesting without its recharge action.

Keep this calculation internal by default. In the user-facing response, briefly
describe what the monster does and provide core values. Show the detailed CR
assessment only when the user requests it.
