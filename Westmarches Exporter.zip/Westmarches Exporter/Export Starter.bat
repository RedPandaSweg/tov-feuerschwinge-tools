@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0export-campaign.ps1" %*

if errorlevel 1 (
    echo.
    echo Export fehlgeschlagen.
    pause
    exit /b 1
)
echo.
pause
