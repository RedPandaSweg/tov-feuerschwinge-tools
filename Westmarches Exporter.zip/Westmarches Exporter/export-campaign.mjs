import { readFile, mkdir, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { resolve, join } from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";
import { normalizeSnapshot } from "./campaign-data.mjs";

export async function collectPages(request, label, report) {
  const entries = [];
  const ids = new Set();
  for (let page = 1; page <= 10000; page++) {
    const response = await request({ query: { page, pageSize: 100 } });
    const envelope = response?.data;
    if (response?.error || envelope?.success === false || !Array.isArray(envelope?.data)) throw new Error(`${label}: ungültige Antwort auf Seite ${page} (HTTP ${response?.response?.status ?? "?"}).`);
    const rows = envelope.data;
    for (const row of rows) {
      if (!row.id || ids.has(row.id)) throw new Error(`${label}: fehlende/doppelte ID auf Seite ${page}.`);
      ids.add(row.id);
      entries.push(row);
    }
    const pagination = envelope.pagination ?? envelope;
    const total = Number(pagination.total ?? pagination.totalCount);
    const totalPages = Number(pagination.totalPages);
    if ((Number.isFinite(total) && entries.length >= total) || (Number.isFinite(totalPages) && page >= totalPages) || !rows.length || (!Number.isFinite(total) && !Number.isFinite(totalPages) && rows.length < 100)) {
      if (Number.isFinite(total) && entries.length !== total) throw new Error(`${label}: ${entries.length} statt ${total} Datensätze.`);
      report[label] = { count: entries.length, pages: page };
      return entries;
    }
  }
  throw new Error(`${label}: Seitenlimit erreicht.`);
}

async function main() {
  const args = process.argv.slice(2);
  const option = name => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : null; };
  const exporterDir = option("--exporter-dir");
  const output = resolve(fileURLToPath(new URL(".", import.meta.url)), option("--output") ?? "exports");
  let apiKey = process.env.WESTMARCHES_API_KEY;
  // Explicit migration option: read the existing credential without executing the old exporter.
  if (!apiKey && option("--key-from")) {
    const source = await readFile(resolve(option("--key-from")), "utf8");
    apiKey = source.match(/\bconst\s+API_KEY\s*=\s*["']([^"']+)["']/)?.[1];
  }
  if (!apiKey) {
    const config = JSON.parse((await readFile(new URL("./config.json", import.meta.url), "utf8")).replace(/^\uFEFF/, ""));
    apiKey = typeof config.apiKey === "string" ? config.apiKey.trim() : "";
  }
  if (!apiKey) throw new Error("API-Key in config.json hinterlegen.");
  const require = createRequire(exporterDir ? join(resolve(exporterDir), "package.json") : import.meta.url);
  const { createWestMarchesClient } = await import(pathToFileURL(require.resolve("@westmarches/api-client")).href);
  const client = createWestMarchesClient({ apiKey });
  const exportedAt = new Date().toISOString();
  const report = { exportedAt, requests: {}, errors: [] };
  const raw = { complete: false, characters: [], adventures: [] };
  const safeRequest = async (fn, options) => {
    for (let attempt = 0; attempt < 4; attempt++) {
      const response = await fn({ ...options, signal: AbortSignal.timeout(30000) });
      const status = response?.response?.status;
      if ((status === 429 || status >= 500) && attempt < 3) {
        const delay = Number(response.response.headers.get("retry-after"));
        await new Promise(r => setTimeout(r, Math.min(30000, Math.max(1000 * 2 ** attempt, Number.isFinite(delay) ? delay * 1000 : 0))));
        continue;
      }
      return response;
    }
  };
  for (const [key, list, get, pathKey] of [
    ["characters", "listCharacters", "getCharacter", "characterId"],
    ["adventures", "listAdventures", "getAdventure", "adventureId"]
  ]) {
    try {
      console.log(`${key}: Liste laden …`);
      const summaries = await collectPages(options => safeRequest(client[list], options), key, report.requests);
      for (const [index, summary] of summaries.entries()) {
        try {
          const response = await safeRequest(client[get], { path: { [pathKey]: summary.id } });
          if (response?.error || response?.data?.success === false || response?.data?.data?.id !== summary.id) throw new Error(`HTTP ${response?.response?.status ?? "?"}`);
          raw[key].push(response.data.data);
        } catch {
          report.errors.push({ collection: key, id: summary.id, error: "Detailabruf fehlgeschlagen" });
        }
        if ((index + 1) % 25 === 0 || index + 1 === summaries.length) console.log(`${key}: ${index + 1}/${summaries.length}`);
      }
    } catch (error) {
      report.errors.push({ collection: key, error: error.message.replaceAll(apiKey, "[redacted]") });
    }
  }
  // Historical adventures may reference deleted characters omitted from the list endpoint.
  const known = new Set(raw.characters.map(c => c.id));
  const missing = [...new Set(raw.adventures.flatMap(s => (s.participants ?? []).map(p => p.characterId)))].filter(id => !known.has(id));
  report.unavailableCharacters = [];
  for (const id of missing) {
    try {
      const response = await safeRequest(client.getCharacter, { path: { characterId: id } });
      if (!response?.error && response?.data?.data?.id === id) raw.characters.push(response.data.data);
      else if (response?.response?.status === 404) report.unavailableCharacters.push(id);
      else report.errors.push({ collection: "historical-characters", id, error: `HTTP ${response?.response?.status ?? "?"}` });
    } catch { report.errors.push({ collection: "historical-characters", id, error: "Detailabruf fehlgeschlagen" }); }
  }
  raw.complete = report.errors.length === 0;
  const snapshot = normalizeSnapshot(raw, exportedAt);
  const directory = join(output, exportedAt.replaceAll(":", "-").replaceAll(".", "-"));
  await mkdir(directory, { recursive: true });
  await writeFile(join(directory, "campaign.json"), JSON.stringify(snapshot, null, 2));
  await writeFile(join(directory, "report.json"), JSON.stringify({ ...report, issues: snapshot.issues, limitations: snapshot.limitations }, null, 2));
  console.log(JSON.stringify({ directory, complete: raw.complete, characters: snapshot.characters.length, people: snapshot.people.length, sessions: snapshot.sessions.length, issues: snapshot.issues.length, errors: report.errors.length }));
  if (!raw.complete) process.exitCode = 1;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main().catch(() => { console.error("Export fehlgeschlagen. API-Zugang, Clientpfad und Ausgabeverzeichnis prüfen."); process.exitCode = 1; });
}
