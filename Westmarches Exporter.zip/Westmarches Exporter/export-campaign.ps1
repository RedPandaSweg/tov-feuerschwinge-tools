﻿[CmdletBinding()]
param(
  [string]$ExporterDir = $PSScriptRoot,
  [string]$KeyFrom,
  [string]$OutputDir
)

$ErrorActionPreference = "Stop"
$previousKey = $env:WESTMARCHES_API_KEY

function Resolve-ToolPath([string]$Path) {
  if ([IO.Path]::IsPathRooted($Path)) { return [IO.Path]::GetFullPath($Path) }
  return [IO.Path]::GetFullPath((Join-Path $PSScriptRoot $Path))
}

try {
  $node = Get-Command node -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $node) { throw "Node.js wurde nicht gefunden. Bitte Node.js (Version 20 oder neuer) installieren und den Starter erneut oeffnen." }
  $nodeVersion = (& $node.Source --version) -replace '^v(\d+).*$', '$1'
  if ($LASTEXITCODE -ne 0 -or [int]$nodeVersion -lt 20) { throw "Bitte Node.js Version 20 oder neuer installieren." }

  $scriptPath = Join-Path $PSScriptRoot 'export-campaign.mjs'
  if (-not (Test-Path -LiteralPath $scriptPath -PathType Leaf)) { throw "Exporter nicht gefunden: $scriptPath" }
  $ExporterDir = Resolve-ToolPath $ExporterDir
  if (-not (Test-Path -LiteralPath $ExporterDir -PathType Container)) { throw "Exporterordner nicht gefunden: $ExporterDir" }
  if (-not $OutputDir) { $OutputDir = 'exports' }
  $OutputDir = Resolve-ToolPath $OutputDir

  if (-not (Test-Path -LiteralPath (Join-Path $ExporterDir 'node_modules/@westmarches/api-client/package.json') -PathType Leaf)) {
    $npm = Get-Command npm.cmd -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $npm) { throw "npm wurde nicht gefunden. Bitte Node.js inklusive npm installieren." }
    if (-not (Test-Path -LiteralPath (Join-Path $ExporterDir 'package.json') -PathType Leaf)) { throw "package.json fehlt im Exporterordner: $ExporterDir" }
    Write-Host "API-Client wird eingerichtet (Internetverbindung erforderlich) ..."
    Push-Location -LiteralPath $ExporterDir
    try {
      & $npm.Source install --omit=dev --ignore-scripts --no-audit --no-fund
      if ($LASTEXITCODE -ne 0) { throw "Einrichtung des API-Clients fehlgeschlagen." }
    } finally { Pop-Location }
  }

  $nodeArguments = @($scriptPath, '--exporter-dir', (Join-Path $ExporterDir '.'), '--output', (Join-Path $OutputDir '.'))
  if (-not $env:WESTMARCHES_API_KEY) {
    if ($KeyFrom) {
      $KeyFrom = Resolve-ToolPath $KeyFrom
      if (-not (Test-Path -LiteralPath $KeyFrom -PathType Leaf)) { throw "Datei mit API-Key nicht gefunden: $KeyFrom" }
      $nodeArguments += @('--key-from', $KeyFrom)

    }
  }

  Write-Host "Westmarches-Export wird gestartet ..."
  Write-Host "Ausgabe: $OutputDir"
  & $node.Source @nodeArguments
  if ($LASTEXITCODE -ne 0) { throw "Der Exporter wurde mit Fehlercode $LASTEXITCODE beendet." }
  Write-Host "Export abgeschlossen. Dateien liegen unter: $OutputDir"
} catch {
  Write-Error -Message $_.Exception.Message -ErrorAction Continue
  exit 1
} finally {
  $env:WESTMARCHES_API_KEY = $previousKey
}



